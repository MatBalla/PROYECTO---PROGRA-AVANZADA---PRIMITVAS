package com.texturas2d;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class TrianguloTexturizado {
    private final FloatBuffer vertexBuffer;
    private final FloatBuffer texBuffer;
    private final int program;

    private final float [] vertices = {
      0.0f, 0.6f, 0.0f,//vo
      -0.5f, -0.3f, 0.3f,//v1
      0.5f, -0.3f, 0.0f//v2
    };

    private final float [] texCoords = {
            0.0f, 0.0f, //vo
            0.5f, 0.1f,//v1
            1.0f, 1.0f,//v2
    };

    public TrianguloTexturizado(int program){
        this.program = program;
        vertexBuffer = ByteBuffer.allocateDirect(vertices.length*4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer();

        vertexBuffer.put(vertices).position(0);
        texBuffer = ByteBuffer.allocateDirect(texCoords.length*4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer();
        texBuffer.put(texCoords).position(0);
    }

    public void draw(float[] mvpMatrix){
        GLES20.glUseProgram(program);
        int posHandle = GLES20.glGetAttribLocation(program, "aPosition");
        GLES20.glEnableVertexAttribArray(posHandle);
        GLES20.glVertexAttribPointer(posHandle,
                3, GLES20.GL_FLOAT, false, 0, vertexBuffer);

        int texHandle = GLES20.glGetAttribLocation(program, "aTexCoord");
        GLES20.glEnableVertexAttribArray(texHandle);
        GLES20.glVertexAttribPointer(texHandle,
                3, GLES20.GL_FLOAT, false, 0, texBuffer);

        int mvpHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3);


    }



}
