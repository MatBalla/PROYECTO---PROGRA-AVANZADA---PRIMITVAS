package com.texturas2d;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLUtils;

public class ShaderUtils {

    public static final String VERTEX_SHADER =
            "uniform mat4 uMVPMatrix;" +
            "attribute vec4 aPosition;" +
            "attribute vec2 aTexCoord;" +
            "varying vec2 vTexCoord;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "  vTexCoord = aTexCoord;" +
                    "}";
    public static final String FRAGMENT_SHADER =
            "precision mediump float;" +
            "varying vec2 vTexCoord;" +
            "uniform sampler2D uTexture;" +
                    "void main() {" +
                    "  gl_FragColor = texture2D(uTexture, vTexCoord);" +
                    "}";


    private static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }

    public static int createProgram(String vertex, String fragment){
        int vertexS = loadShader(GLES20.GL_VERTEX_SHADER,vertex);
        int fragmentS = loadShader(GLES20.GL_FRAGMENT_SHADER,fragment);
        int program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vertexS);
        GLES20.glAttachShader(program, fragmentS);
        GLES20.glLinkProgram(program);
        return program;
    }

    public static int loadTexture(Context c, int id){
      int [] t = new int[1];
      GLES20.glGenTextures(1, t, 0);
      Bitmap b = BitmapFactory.decodeResource(c.getResources(), id);//permite transfromar el bitmap, a un bitmap textura
      GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0]);

      GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
      GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);

      GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0);
      b.recycle();
      return t[0];
    }





}
