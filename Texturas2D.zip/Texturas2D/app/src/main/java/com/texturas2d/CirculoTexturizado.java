package com.texturas2d;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class CirculoTexturizado {
    private final FloatBuffer vertexBuffer;
    private final FloatBuffer texBuffer;
    private final int program;
    private final int vertexCount;

    public CirculoTexturizado(int program){
        this.program = program;
        int segments = 40; //Segmentos
        float radius = 0.4f; //radio

        float [] vertices = new float[(segments +2) *3];
        float [] texCoords = new float[(segments +2) *2];

        //punto central
        vertices[0] = 0f;
        vertices[1] = 0f;
        vertices[2] = 0f;

        texCoords[0] = 0.5f;
        texCoords[1] = 0.5f;
        
        for (int i = 0; i <= segments; i++) {

            float angle = (float) (2 * Math.PI * i / segments);
            float x = radius * (float) Math.cos(angle);
            float y = radius * (float) Math.sin(angle);
            int v = (i + 1) * 3;
            vertices[v] = x;
            vertices[v + 1] = y;
            vertices[v + 2] = 0f;
            int t = (i + 1) * 2;
            texCoords[t] = (x / radius + 1) / 2;
            texCoords[t + 1] = (y / radius + 1) / 2;

        }
        vertexCount = segments + 2;

        vertexBuffer = ByteBuffer.allocateDirect(vertices.length*4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer();

        vertexBuffer.put(vertices).position(0);
        texBuffer = ByteBuffer.allocateDirect(texCoords.length*4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer();
        texBuffer.put(texCoords).position(0);
    }

    public void draw(float[] mvpMatrix){
        GLES20.glUseProgram(program);
        int posHandle = GLES20.glGetAttribLocation(program, "aPosition");
        GLES20.glEnableVertexAttribArray(posHandle);
        GLES20.glVertexAttribPointer(posHandle,
                3, GLES20.GL_FLOAT, false, 0, vertexBuffer);

        int texHandle = GLES20.glGetAttribLocation(program, "aTexCoord");
        GLES20.glEnableVertexAttribArray(texHandle);
        GLES20.glVertexAttribPointer(texHandle,
                2, GLES20.GL_FLOAT, false, 0, texBuffer);

        int mvpHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, vertexCount);


    }





}
