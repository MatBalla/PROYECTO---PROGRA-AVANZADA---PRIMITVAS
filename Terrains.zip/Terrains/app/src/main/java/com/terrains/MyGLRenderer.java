package com.terrains;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {
    private final Context context;
    private Terrain mTerreno;

    private final float[] vPMatrix = new float[16];
    private final float[] projection = new float[16];
    private final float[] view = new float[16];
    private final float[] model = new float[16]; // Matriz para rotar el objeto

    private float angle = 0;

    public MyGLRenderer(Context context) {
        this.context = context;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.1f, 0.1f, 0.2f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        float[] heights = loadHeightsFromImage(R.drawable.mapa_terreno);
        if (heights != null) {
            int size = (int) Math.sqrt(heights.length);
            mTerreno = new Terrain(heights, size);
        }
    }

    private float[] loadHeightsFromImage(int resId) {
        Bitmap b = BitmapFactory.decodeResource(context.getResources(), resId);
        if (b == null) return null;
        int w = b.getWidth();
        int h = b.getHeight();
        float[] heights = new float[w * h];
        int[] pixels = new int[w * h];
        b.getPixels(pixels, 0, w, 0, 0, w, h);
        for (int i = 0; i < pixels.length; i++) {
            // Ajustamos la altura para que no sea excesiva
            heights[i] = (float) Color.red(pixels[i]) / 4.0f;
        }
        b.recycle();
        return heights;
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        // Seguridad: Si el terreno no se ha cargado, no intentar dibujar
        if (mTerreno == null) return;

        angle += 0.5f;

        // 1. Configurar Cámara
        Matrix.setLookAtM(view, 0,
                0f, 1000f, 1000f,  // Un poco más atrás para asegurar visión
                0f, 0f, 0f,
                0f, 1f, 0f);

        // 2. Rotación
        Matrix.setIdentityM(model, 0);
        Matrix.rotateM(model, 0, angle, 0f, 1f, 0f);

        // 3. Combinar matrices (Ojo aquí: El orden debe ser Proyección * Vista * Modelo)
        float[] vMatrix = new float[16];
        Matrix.multiplyMM(vMatrix, 0, view, 0, model, 0);
        Matrix.multiplyMM(vPMatrix, 0, projection, 0, vMatrix, 0);

        mTerreno.draw(vPMatrix);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        float ratio = (float) width / height;
        // Aumentamos el plano lejano (Far) a 3000 para que no se corte el mapa
        Matrix.perspectiveM(projection, 0, 45, ratio, 10f, 3000f);
    }
}