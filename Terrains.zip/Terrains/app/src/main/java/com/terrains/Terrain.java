package com.terrains;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.nio.IntBuffer;

public class Terrain {
    private FloatBuffer vertexBuffer;
    private IntBuffer drawListBuffer; // Cambiado de ShortBuffer a IntBuffer
    private int mProgram;
    private int mPositionHandle;
    private int mMVPMatrixHandle;
    private int indexCount;

    public Terrain(float[] heights, int size) {
        mProgram = ShaderUtils.createProgram(ShaderUtils.VERTEX_SHADER, ShaderUtils.FRAGMENT_SHADER);

        float scale = 2.0f;
        float[] coords = new float[size * size * 3];
        int vIdx = 0;
        for (int z = 0; z < size; z++) {
            for (int x = 0; x < size; x++) {
                coords[vIdx++] = (x - size / 2f) * scale;
                coords[vIdx++] = heights[z * size + x];
                coords[vIdx++] = (z - size / 2f) * scale;
            }
        }

        // Cambiamos a int[] porque 256*256 > 32767
        int[] indices = new int[(size - 1) * (size - 1) * 6];
        int iIdx = 0;
        for (int z = 0; z < size - 1; z++) {
            for (int x = 0; x < size - 1; x++) {
                int start = (z * size + x);
                indices[iIdx++] = start;
                indices[iIdx++] = (start + size);
                indices[iIdx++] = (start + size + 1);
                indices[iIdx++] = start;
                indices[iIdx++] = (start + size + 1);
                indices[iIdx++] = (start + 1);
            }
        }
        indexCount = indices.length;

        vertexBuffer = ByteBuffer.allocateDirect(coords.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        vertexBuffer.put(coords).position(0);

        // AllocateDirect ahora usa 4 bytes por cada entero (indices.length * 4)
        drawListBuffer = ByteBuffer.allocateDirect(indices.length * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
        drawListBuffer.put(indices).position(0);
    }

    public void draw(float[] mvpMatrix) {
        GLES20.glUseProgram(mProgram);
        mPositionHandle = GLES20.glGetAttribLocation(mProgram, "aPosition");
        GLES20.glEnableVertexAttribArray(mPositionHandle);
        GLES20.glVertexAttribPointer(mPositionHandle, 3, GLES20.GL_FLOAT, false, 12, vertexBuffer);

        mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0);

        // IMPORTANTE: Cambiado a GL_UNSIGNED_INT
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_INT, drawListBuffer);

        GLES20.glDisableVertexAttribArray(mPositionHandle);
    }
}