package com.terrains;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class MyGLSurfaceView extends GLSurfaceView {

    private final MyGLRenderer renderer;

    public MyGLSurfaceView(Context context) {
        super(context);

        // 1. IMPORTANTE: Configurar la versión ANTES de setRenderer
        // Usamos 3 para que coincida con "#version 300 es" de tus shaders
        setEGLContextClientVersion(3);

        // 2. Inicializar el renderer
        renderer = new MyGLRenderer(context);

        // 3. Establecer el renderer
        setRenderer(renderer);

        // Opcional: Renderizar solo cuando cambien los datos (ahorra batería)
        // setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
}
