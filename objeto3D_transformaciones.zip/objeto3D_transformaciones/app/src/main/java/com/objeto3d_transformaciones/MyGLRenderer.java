package com.objeto3d_transformaciones;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {
    private Ejes ejes;
    private Cylinder cuadrado;
    private Cube cuadrado2;
    private Cube cuadrado3;
    private Cylinder cilindro;
    private Cylinder prisma_hex;
    private Cone cono;
    private Sphere esfera;
    private Torus dona;
    private Piramide piramide;
    private Cone piramide_cuadrangular;

    private TruncatedPyramid piramide_Truncada;



    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    private final float[] mVPMatrix = new float[16];
    private final float[] mModelMatrix = new float[16];

    private float angle = 1.0f; //En radianes
    private float angle_torus = 290.0f; //En radianes



    // Parámetros de cámara
    //SI QUIERES VER TIPO PLANO DIBUJO: X=2, Y=2, Z=2
    public float camaraX = 2.5f;
    public float camaraY = 1.5f;
    public float camaraZ = 2.5f;


    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        Matrix.setLookAtM(
                mViewMatrix, 0,
                camaraX, camaraY, camaraZ,   // Posición de cámara
                0f, 0f, 0f,                  // Siempre mira al centro
                0f, 1f, 0f                   // Vector "arriba" (eje Y)
        );

        //EJES -----------------------------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0); // La matriz modelo es la identidad para los ejes
        float [] mvMatrix_Ejes = new float[16];
        Matrix.multiplyMM(mvMatrix_Ejes, 0, mViewMatrix, 0, mModelMatrix, 0);
        float [] mVPMatrix_Ejes = new float[16];
        Matrix.multiplyMM(mVPMatrix_Ejes, 0, mProjectionMatrix, 0, mvMatrix_Ejes, 0);
        //ejes.draw(mVPMatrix_Ejes); // Dibuja los ejes X, Y, Z

        //ejes.draw(mVPMatrix); //ejes ultima figura dibujada
        //----------------------------------------------------------------------------------------

        //CUBO1---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.47f,//x
                0.40f,//y
                0.47f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                0f,//y
                0f//z
        );


        float[] mv1 = new float[16];
        Matrix.multiplyMM(mv1, 0, mViewMatrix, 0, mModelMatrix, 0);
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mv1, 0);
        cuadrado.draw(mVPMatrix);
        //ejes.draw(mVPMatrix); //ejes cuadrado
        //-----------------------------------------------------------------------------------------



        //CUBO2---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.4f,//x
                0.5f,//y
                0.4f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.5f,//x
                0f,//y
                -0.5f//z
        );


        float[] mv2 = new float[16];
        Matrix.multiplyMM(mv2, 0, mViewMatrix, 0, mModelMatrix, 0);
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mv2, 0);
        cuadrado2.draw(mVPMatrix);
        //ejes.draw(mVPMatrix); //ejes cuadrado
        //-----------------------------------------------------------------------------------------

        //CUBO3---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.4f,//x
                0.5f,//y
                0.4f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                -0.5f,//x
                0f,//y
                0.5f//z
        );


        float[] mv3 = new float[16];
        Matrix.multiplyMM(mv3, 0, mViewMatrix, 0, mModelMatrix, 0);
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mv3, 0);
        cuadrado3.draw(mVPMatrix);
        //ejes.draw(mVPMatrix); //ejes cuadrado
        //-----------------------------------------------------------------------------------------

        //CILINDRO---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.25f,//x
                0.25f,//y
                0.25f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                1.7f,//y
                0f//z
        );

        float [] mvMatrix_cilindro = new float[16];
        Matrix.multiplyMM(mvMatrix_cilindro, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix_cilindro, 0);
        cilindro.draw(mVPMatrix);
        //ejes.draw(mVPMatrix); //ejes cilindro
        //-----------------------------------------------------------------------------------------



        //PRISMA HEXAGONAL---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.25f,//x
                0.25f,//y
                0.25f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.3f,//x
                2.15f,//y
                0.3f//z
        );

        float [] mvMatrix_prisma_hex = new float[16];
        Matrix.multiplyMM(mvMatrix_prisma_hex, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix_prisma_hex, 0);
        prisma_hex.draw(mVPMatrix);
        //ejes.draw(mVPMatrix); //ejes prisma hexagonal
        //-----------------------------------------------------------------------------------------


        //BASE CAMARA
        //CONO---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.3f,//x
                0.3f,//y
                0.3f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                -1.5f,//y
                0f//z
        );

        float [] mvMatrix_cono = new float[16];
        Matrix.multiplyMM(mvMatrix_cono, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix_cono, 0);
        cono.draw(mVPMatrix);
        //ejes.draw(mVPMatrix);//ejes cono
        //-----------------------------------------------------------------------------------------


        //ESFERA---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.25f,//x
                0.25f,//y
                0.25f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.1f,//x
                0f,//y
                0.1f//z
        );

        float [] mvMatrix_esfera = new float[16];
        Matrix.multiplyMM(mvMatrix_esfera, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix_esfera, 0);
        esfera.draw(mVPMatrix);
        //ejes.draw(mVPMatrix);//ejes esfera
        //-----------------------------------------------------------------------------------------


        //TORUS---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.25f,//x
                0.25f,//y
                0.25f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle_torus,//angulo de rotacion
                1,//x - (0,1)
                0,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                1.9f,//x
                1f,//y
                -2f//z
        );

        float [] mvMatrix_torus = new float[16];
        Matrix.multiplyMM(mvMatrix_torus, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix_torus, 0);
        dona.draw(mVPMatrix);
        //angle_torus +=1.0f;
        //ejes.draw(mVPMatrix);//ejes dona
        //-----------------------------------------------------------------------------------------


        //PIRAMIDE---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0); // Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.025f,//x
                0.025f,//y
                0.025f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                -0.6f,//x
                -9.0f,//y
                24f//z
        );

        float [] mvMatrix_piramide = new float[16];
        Matrix.multiplyMM(mvMatrix_piramide, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix_piramide, 0);

        piramide.draw(mVPMatrix);
        //ejes.draw(mVPMatrix); //ejes piramide
        //-----------------------------------------------------------------------------------------


        //Piramide cuadtangular---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.05f,//x
                0.05f,//y
                0.05f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                7f,//x
                7f,//y
                -5.0f//z
        );

        float [] mvMatrix_piramide_cuadr = new float[16];
        Matrix.multiplyMM(mvMatrix_piramide_cuadr, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix_piramide_cuadr, 0);
        piramide_cuadrangular.draw(mVPMatrix);
        //ejes.draw(mVPMatrix);//ejes cono
        //-----------------------------------------------------------------------------------------



        //PIRAMIDE TRUNCADA---------------------------------------------------------------
        Matrix.setIdentityM(mModelMatrix, 0);// Reiniciar la matriz modelo
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                mModelMatrix, //Matriz modelo
                0,//indice
                0.05f,//x
                0.05f,//y
                0.05f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                mModelMatrix,//Matriz modelo
                0, //indice
                angle,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                mModelMatrix, //Matriz modelo
                0,//indice
                -5f,//x
                9f,//y
                8.0f//z
        );

        float [] mvMatrix_piramide_truncada = new float[16];
        Matrix.multiplyMM(mvMatrix_piramide_truncada, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix_piramide_truncada, 0);
        piramide_Truncada.draw(mVPMatrix);
        //ejes.draw(mVPMatrix);//ejes piramide truncada
        //-----------------------------------------------------------------------------------------




        //Forma que rote constantemente
        //con -= gira al otro lado
        //angle+= 1.0f; //velocidad se cambia este 1.0 a algun valor mayor



    }


    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.1961f, 0.2941f, 0.4667f, 1.0f) ;
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        //Ejes
        ejes = new Ejes();
        //Cubo1
        cuadrado = new Cylinder(1f, 1.5f, 4);
        //Cubo2
        cuadrado2 = new Cube(1f, 1.5f, 4);
        //Cubo3
        cuadrado3 = new Cube(1f, 1.5f, 4);
        //Cilindro
        cilindro = new Cylinder(1f, 0.7f, 30);
        //Prisma hexagonal
        prisma_hex = new Cylinder(1.5f, 0.5f, 6);
        //Cono
        cono = new Cone(1f, 2, 30);
        //Esfera
        esfera = new Sphere(1.3f, 30, 30);
        //Torus
        dona = new Torus();
        //Piramide
        piramide = new Piramide();
        //Piramide cuadrangular
        piramide_cuadrangular = new Cone(1f, 2, 4);
        //Piramide Truncada
        piramide_Truncada = new TruncatedPyramid();

    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0,0,width,height);
        float ratio = (float) width / height;

        Matrix.frustumM(
                mProjectionMatrix, 0,
                -ratio, ratio,
                -1, 1,
                2f, 10f
        );
    }

    //para cargar el shader vertex o el shader fragment (tipo de shader, código del shader em GLSL)
    public static int loadShader(int type, String shaderCode){
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        //compilar el shader
        GLES20.glCompileShader(shader);
        //retorna el id del shader
        return shader;

    }
}

