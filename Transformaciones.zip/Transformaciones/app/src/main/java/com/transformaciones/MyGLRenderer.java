package com.transformaciones;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {

    private Line ejex;
    private Line1 ejey;
    private Line2 ejez;


    private Piramide piramide;
    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    private final float[] mVPMatrix = new float[16];
    private final float[] mModelMatrix = new float[16];

    private float angle = 0.0f;



    // NUEVAS VARIABLES PARA ROTACIÓN
    private float anguloRotacion = 0f;        // Ángulo actual en grados
    private float radioOrbita = 3.5f;   // Radio de la órbita circular
    private float velocidadRotacion = 0.5f; // Grados por frame (ajustable)



    // Parámetros de cámara
    public float camaraX = 0.0f;
    public float camaraY = 2.0f;
    public float camaraZ = -8.0f;


    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        Matrix.setLookAtM(
                mViewMatrix, 0,
                camaraX, camaraY, camaraZ,   // Posición de cámara (actualizada)
                0f, 0f, 0f,                  // Siempre mira al centro
                0f, 1f, 0f                   // Vector "arriba" (eje Y)
        );

        Matrix.setIdentityM(mModelMatrix, 0); //para que este en el origen

        float [] mvMatrix = new float[16];
        Matrix.multiplyMM(mvMatrix, 0, mViewMatrix, 0, mModelMatrix, 0);//matriz nueva = matriz vista * matriz modelo
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix, 0);
        //ejex.draw(mVPMatrix);
        //ejey.draw(mVPMatrix);
        //ejez.draw(mVPMatrix);


        //transformaciones




    }


    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.1961f, 0.2941f, 0.4667f, 1.0f) ;
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        ejex = new Line();
        ejey = new Line1();
        ejez = new Line2();

        //Piramide
        piramide = new Piramide();

    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0,0,width,height);
        float ratio = (float) width / height;

        Matrix.frustumM(
                mProjectionMatrix, 0,
                -ratio, ratio,
                -1, 1,
                2f, 10f
        );
    }

    //para cargar el shader vertex o el shader fragment (tipo de shader, código del shader em GLSL)
    public static int loadShader(int type, String shaderCode){
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        //compilar el shader
        GLES20.glCompileShader(shader);
        //retorna el id del shader
        return shader;

    }
}

