package com.iluminacionspotlight;

import android.opengl.GLES20;

public class ShaderUtils {
    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }


    public static int createProgram(String vertex, String fragment){
        int vertexS = loadShader(GLES20.GL_VERTEX_SHADER, vertex);
        int fragmentS = loadShader(GLES20.GL_FRAGMENT_SHADER, fragment);
        int program
    }
}
