package com.iluminacionspotlight;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
public class Pyramid {
    private final FloatBuffer vertexBuffer;
    private final int mProgram;

    //arreglo de coordenadas de vertices y normales
    private final float [] vertices = {
            //Base
            -1,0,-1,     0,-1,0,
            1,0,-1,      0,-1,0,
            1,0,1,       0,-1,0,
            -1,0,1,      0,-1,0,

            //Lados
            -1,0,-1,    -0.5f,0.5f,-0.5f,
            1,0,-1,      0.5f,0.5f,-0.5f,
            0,1,0,       0,0.5f,0,

            1,0,-1,      0.5f,0.5f,-0.5f,
            1,0,1,       0.5f,0.5f,0.5f,
            0,1,0,       0,0.5f,0,

            1,0,1,       0.5f,0.5f,0.5f,
            -1,0,1,     -0.5f,0.5f,0.5f,
            0,1,0,       0,0.5f,0,

            -1,0,1,     -0.5f,0.5f,0.5f,
            -1,0,-1,    -0.5f,0.5f,-0.5f,
            0,1,0,       0,0.5f,0
    };

    public Pyramid(){

    }



}
