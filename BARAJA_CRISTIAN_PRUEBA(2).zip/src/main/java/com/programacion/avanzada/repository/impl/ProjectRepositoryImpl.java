package com.programacion.avanzada.repository.impl;

import com.programacion.avanzada.cdi.EntityManagerFab;
import com.programacion.avanzada.cdi.ExecutorServiceManager;
import com.programacion.avanzada.db.Project;
import com.programacion.avanzada.repository.inter.ProjectRepository;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class ProjectRepositoryImpl implements ProjectRepository {
    private EntityManager em;
    private ExecutorService serviceManager;

    @Inject
    public ProjectRepositoryImpl(ExecutorService serviceManager, EntityManager em){
        this.serviceManager = serviceManager;
        this.em = em;
    }


    @Override
    public Project findById(Integer id) {
        serviceManager.submit(
                () -> {
                     em.find(Project.class, id);
                }
        );
        return null;
    }

    @Override
    public List<Project> findAll() {
        serviceManager.submit(
                () -> {
                    String query = "SELECT p FROM Project p";
                    em.createQuery(query, Project.class).getResultList();
                }
        );
        return List.of();
    }
}
