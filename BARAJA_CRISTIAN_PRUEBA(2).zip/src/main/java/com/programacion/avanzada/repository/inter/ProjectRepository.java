package com.programacion.avanzada.repository.inter;

import com.programacion.avanzada.db.Project;

import java.util.List;
import java.util.concurrent.Future;

public interface ProjectRepository {
    Project findById(Integer id);
    List<Project> findAll();
}
