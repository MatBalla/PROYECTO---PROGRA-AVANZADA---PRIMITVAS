package com.programacion.avanzada.repository.impl;

import com.programacion.avanzada.cdi.EntityManagerFab;
import com.programacion.avanzada.db.Usuario;
import com.programacion.avanzada.repository.inter.UsuarioRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

@ApplicationScoped
public class UsuarioRepositoryImpl implements UsuarioRepository {
    private EntityManager em;
    private ExecutorService service;

    @Inject
    public UsuarioRepositoryImpl(ExecutorService service, EntityManager em) {
        this.service = service;
        this.em = em;
    }

    @Override
    public Usuario findById(Integer id) {
        service.submit(
                () -> {
                    em.find(Usuario.class, id);
                }
        );
        return null;
    }

    @Override
    public List<Usuario> findAll() {
        service.submit(
                () -> {
                    String query = "SELECT u FROM Usuario u";
                    em.createQuery(query, Usuario.class).getResultList();
                }
        );
        return List.of();
    }
}
