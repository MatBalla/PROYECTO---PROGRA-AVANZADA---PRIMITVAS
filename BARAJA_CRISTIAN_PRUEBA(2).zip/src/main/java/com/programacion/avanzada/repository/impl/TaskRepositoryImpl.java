package com.programacion.avanzada.repository.impl;

import com.programacion.avanzada.db.Task;
import com.programacion.avanzada.repository.inter.TaskRepository;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class TaskRepositoryImpl implements TaskRepository {
    private EntityManager em;
    private ExecutorService service;

    @Inject
    public TaskRepositoryImpl(EntityManager em, ExecutorService service) {
        this.em = em;
        this.service = service;
    }

    @Override
    public Task findById(Integer id) {
        service.submit(
                () -> {
                    em.find(Task.class, id);
                }
        );
        return null;
    }

    @Override
    public List<Task> findAll() {
        service.submit(
                () -> {
                    String query = "SELECT t FROM Task t";
                    em.createQuery(query, Task.class).getResultList();
                }
        );
        return List.of();
    }
}
