package com.programacion.avanzada.repository.inter;

import com.programacion.avanzada.db.Task;

import java.util.List;
import java.util.concurrent.Future;

public interface TaskRepository {
    Task findById(Integer id);

    List<Task> findAll();
}
