package com.programacion.avanzada.repository.inter;

import com.programacion.avanzada.db.Usuario;
import jakarta.persistence.criteria.CriteriaBuilder;

import java.util.List;
import java.util.concurrent.Future;

public interface UsuarioRepository {
    Usuario findById(Integer id);

    List<Usuario> findAll();
}
