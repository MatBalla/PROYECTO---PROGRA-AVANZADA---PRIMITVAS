package com.programacion.avanzada.DTO;

public record TaskCompleted(String username, Integer conteo) {
}
