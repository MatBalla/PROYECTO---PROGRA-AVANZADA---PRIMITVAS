package com.programacion.avanzada.DTO;

public record TaskSummary(String tituloTarea, String nombreProyecto, String username) {
}
