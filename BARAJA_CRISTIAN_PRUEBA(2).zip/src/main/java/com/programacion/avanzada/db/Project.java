package com.programacion.avanzada.db;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.beans.ConstructorProperties;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@Table(name = "project")
@AllArgsConstructor
@NoArgsConstructor
public class Project {
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "gen_proj")
    @TableGenerator(name = "gen_proj", table = "claves_primarias")
    private Integer id;

    @Column
    private LocalDateTime created;

    @Column(length = 32)
    private String name;

    @Column
    private Integer version;

    @OneToMany(mappedBy = "project", fetch = FetchType.LAZY)
    private List<Task> taskList;
}
