package com.programacion.avanzada.db;

import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaBuilder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "tasks")
@NoArgsConstructor
@AllArgsConstructor
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "gen_task")
    @TableGenerator(name = "gen_task", table = "claves_primarias")
    private Integer id;

    @Column
    private LocalDateTime created;

    @Column(length = 64)
    private String title;

    @Column
    private LocalDateTime completed;

    @Column(length = 128)
    private String description;

    @Column
    private Integer version;

    @Column
    private Priority priority;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "project")
    private Project project;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user")
    private Usuario user;
}

enum Priority{
    MAXIMA, MEDIA, MINIMA
        }
