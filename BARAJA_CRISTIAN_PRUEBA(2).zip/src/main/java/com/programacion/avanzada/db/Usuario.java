package com.programacion.avanzada.db;


import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaBuilder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@Table
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "gen_user")
    @TableGenerator(name = "gen_user", table = "claves_primarias")
    private Integer id;

    @Column(length = 32)
    private String password;

    @Column(length = 32)
    private String name;

    @Column
    private LocalDateTime created;

    @Column
    private Integer version;

    @OneToMany(mappedBy = "usuario", fetch = FetchType.LAZY)
    private List<Task> tasks;

}
