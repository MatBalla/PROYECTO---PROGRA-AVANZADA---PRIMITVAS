package com.programacion.avanzada.services;

import com.programacion.avanzada.DTO.TaskCompleted;
import com.programacion.avanzada.DTO.TaskSummary;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.concurrent.ExecutorService;

@ApplicationScoped
public class DatabaseServices {
    private EntityManager em;
    private ExecutorService serviceManager;

    @Inject
    public DatabaseServices(EntityManager em, ExecutorService serviceManager) {
        this.em = em;
        this.serviceManager = serviceManager;
    }

    public TaskSummary taskSummaryConsult(){
        String query = "SELECT NEW com.programacion.avanzada.DTO.TaskSummary(t.title, t.project.name, t.user.name)" +
                " FROM Task t" +
                " WHERE MONTH(t.created) IN (01)";
        return em.createQuery(query, TaskSummary.class).getSingleResult();
    }

    public TaskCompleted taskCompletedConsult(){
        String query = "SELECT NEW com.programacion.avanzada.DTO. TaskCompleted(t.user.name, count(t))" +
                " FROM Task t " +
                " WHERE t.complete IS NOT NULL " +
                " AND count(t) > 5" +
                " ORDER BY count(t) DESC";
        return em.createQuery(query, TaskCompleted.class).getSingleResult();
    }
}
