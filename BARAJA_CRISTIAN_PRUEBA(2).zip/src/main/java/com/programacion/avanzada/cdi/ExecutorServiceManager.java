package com.programacion.avanzada.cdi;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@ApplicationScoped
public class ExecutorServiceManager {
    private ExecutorService executorService;
    private int nCores = Runtime.getRuntime().availableProcessors();

    @ApplicationScoped
    @Produces
    public ExecutorService createExecutorService(){
        this.executorService = Executors.newFixedThreadPool(nCores);
        return executorService;
    }

    public void closeExec(){
        executorService.close();
    }

}
