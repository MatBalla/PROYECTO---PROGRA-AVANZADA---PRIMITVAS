package com.proyectofinal;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

public class MyGLSurfaceView extends GLSurfaceView {

    private final MyGLRenderer renderer;
    private float previousX;
    private float previousY;
    private final float TOUCH_SCALE_FACTOR = 0.3f;
    private final float PAN_SCALE_FACTOR = 0.01f;
    private final ScaleGestureDetector scaleDetector;
    public MyGLSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new MyGLRenderer(context);
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        scaleDetector = new ScaleGestureDetector(context, new ScaleListener());
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        float x = e.getX();
        float y = e.getY();

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                float dx = x - previousX;
                float dy = y - previousY;

                if (e.getPointerCount() == 1 && !scaleDetector.isInProgress()) {
                    renderer.angleY += dx * TOUCH_SCALE_FACTOR;
                    renderer.angleX += dy * TOUCH_SCALE_FACTOR;
                    if (renderer.angleX > 89f) renderer.angleX = 89f;
                    if (renderer.angleX < -89f) renderer.angleX = -89f;
                }

                else if (e.getPointerCount() == 2) {
                    renderer.camPosX -= dx * PAN_SCALE_FACTOR;
                    renderer.camPosZ -= dy * PAN_SCALE_FACTOR;
                }
                break;
        }
        previousX = x;
        previousY = y;
        return true;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            renderer.distancia /= detector.getScaleFactor();
            if (renderer.distancia < 2.0f) renderer.distancia = 2.0f;
            if (renderer.distancia > 100.0f) renderer.distancia = 100.0f;
            return true;
        }
    }

}