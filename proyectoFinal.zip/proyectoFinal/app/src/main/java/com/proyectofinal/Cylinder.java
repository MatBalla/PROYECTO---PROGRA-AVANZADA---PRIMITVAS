package com.proyectofinal;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Cylinder {
    private FloatBuffer vBuffer, nBuffer, tBuffer;
    private FloatBuffer topVBuffer, topNBuffer, topTBuffer;
    private FloatBuffer botVBuffer, botNBuffer, botTBuffer;
    private int sideCount, capCount;

    public Cylinder(float rX, float rZ, float h, int seg) {
        float h2 = h / 2f;
        float[] v = new float[(seg + 1) * 2 * 3];
        float[] n = new float[(seg + 1) * 2 * 3];
        float[] t = new float[(seg + 1) * 2 * 2];
        int vi=0, ni=0, ti=0;

        for (int i = 0; i <= seg; i++) {
            float u = (float) i / seg;
            float ang = (float) (2.0 * Math.PI * u);
            float cos = (float) Math.cos(ang), sin = (float) Math.sin(ang);
            float x = rX * cos, z = rZ * sin;

            for (int j = 0; j < 2; j++) {
                float y = (j == 0) ? -h2 : h2;
                v[vi++]=x; v[vi++]=y; v[vi++]=z;
                n[ni++]=cos; n[ni++]=0; n[ni++]=sin;
                t[ti++]=u; t[ti++]=(j == 0 ? 1f : 0f);
            }
        }
        sideCount = v.length / 3;
        vBuffer = createFB(v); nBuffer = createFB(n); tBuffer = createFB(t);

        capCount = seg + 2;
        float[] topV = new float[capCount * 3], topN = new float[capCount * 3], topT = new float[capCount * 2];
        float[] botV = new float[capCount * 3], botN = new float[capCount * 3], botT = new float[capCount * 2];

        topV[0]=0; topV[1]=h2; topV[2]=0; topN[1]=1f;
        botV[0]=0; botV[1]=-h2; botV[2]=0; botN[1]=-1f;

        for (int i = 0; i <= seg; i++) {
            float ang = (float) (2.0 * Math.PI * i / seg);
            float x = (float)(rX * Math.cos(ang)), z = (float)(rZ * Math.sin(ang));
            int idxV = (i+1)*3;
            topV[idxV]=x; topV[idxV+1]=h2; topV[idxV+2]=z; topN[idxV+1]=1f;
            botV[idxV]=x; botV[idxV+1]=-h2; botV[idxV+2]=z; botN[idxV+1]=-1f;
        }
        topVBuffer=createFB(topV); topNBuffer=createFB(topN); topTBuffer=createFB(topT);
        botVBuffer=createFB(botV); botNBuffer=createFB(botN); botTBuffer=createFB(botT);
    }

    public void draw(float[] mvp, float[] mv, TextureShader shader, int texID) {
        GLES20.glUseProgram(shader.program);
        GLES20.glUniformMatrix4fv(shader.mvpH, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(shader.mvH, 1, false, mv, 0);

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texID);
        GLES20.glUniform1i(shader.texUnitH, 0);

        GLES20.glEnableVertexAttribArray(shader.posH);
        GLES20.glEnableVertexAttribArray(shader.normH);
        GLES20.glEnableVertexAttribArray(shader.texH);

        drawPart(shader, vBuffer, nBuffer, tBuffer, GLES20.GL_TRIANGLE_STRIP, sideCount);
        drawPart(shader, topVBuffer, topNBuffer, topTBuffer, GLES20.GL_TRIANGLE_FAN, capCount);
        drawPart(shader, botVBuffer, botNBuffer, botTBuffer, GLES20.GL_TRIANGLE_FAN, capCount);

        GLES20.glDisableVertexAttribArray(shader.posH);
        GLES20.glDisableVertexAttribArray(shader.normH);
        GLES20.glDisableVertexAttribArray(shader.texH);
    }

    private void drawPart(TextureShader s, FloatBuffer v, FloatBuffer n, FloatBuffer t, int mode, int count) {
        GLES20.glVertexAttribPointer(s.posH, 3, GLES20.GL_FLOAT, false, 0, v);
        GLES20.glVertexAttribPointer(s.normH, 3, GLES20.GL_FLOAT, false, 0, n);
        GLES20.glVertexAttribPointer(s.texH, 2, GLES20.GL_FLOAT, false, 0, t);
        GLES20.glDrawArrays(mode, 0, count);
    }

    private FloatBuffer createFB(float[] d) {
        FloatBuffer fb = ByteBuffer.allocateDirect(d.length * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer();
        fb.put(d);
        fb.position(0);
        return fb;
    }
}
