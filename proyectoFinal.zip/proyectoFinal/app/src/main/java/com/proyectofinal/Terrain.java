package com.proyectofinal;

import android.opengl.GLES20;
import android.util.Log;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

public class Terrain {
    private FloatBuffer vertexBuffer;
    private IntBuffer drawListBuffer;
    private int mProgram;
    private int mPositionHandle;
    private int mMVPMatrixHandle;
    private int indexCount;

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
            "attribute vec4 aPosition;" +
            "varying vec3 vPosition;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "  vPosition = aPosition.xyz;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
            "varying vec3 vPosition;" +
            "float rand(vec2 co){" +
            "  return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);" +
            "}" +
                    "void main() {" +
                    "  vec3 trackBlack = vec3(0.02, 0.02, 0.03);" + // Asfalto
                    "  vec3 mountainWhite = vec3(0.95, 0.95, 1.0);" + // Blanco puro
                    "  float noise = rand(vPosition.xz) * 0.10;" +
                    "  float h = clamp(vPosition.y / 12.0, 0.0, 1.0);" +
                    "  vec3 color = mix(trackBlack, mountainWhite, smoothstep(0.9, 0.9, h));" +
                    "  if(h > 0.8) {" +
                    "     color -= noise;" +
                    "  }" +
                    "  float exposure = mix(1.0, 1.5, h);" +
                    "  gl_FragColor = vec4(color * exposure, 1.0);" +
                    "}";

    public Terrain(float[] heights, int size) {
        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);

        float scale = 6f;
        float heightScale = 8f;

        float[] coords = new float[size * size * 3];
        int vIdx = 0;
        for (int z = 0; z < size; z++) {
            for (int x = 0; x < size; x++) {
                coords[vIdx++] = (x - size / 2f) * scale;
                coords[vIdx++] = heights[z * size + x] * heightScale;
                coords[vIdx++] = (z - size / 2f) * scale;
            }
        }

        int[] indices = new int[(size - 1) * (size - 1) * 6];
        int iIdx = 0;
        for (int z = 0; z < size - 1; z++) {
            for (int x = 0; x < size - 1; x++) {
                int start = (z * size + x);
                indices[iIdx++] = start;
                indices[iIdx++] = (start + size);
                indices[iIdx++] = (start + size + 1);
                indices[iIdx++] = start;
                indices[iIdx++] = (start + size + 1);
                indices[iIdx++] = (start + 1);
            }
        }
        indexCount = indices.length;
        vertexBuffer = ByteBuffer.allocateDirect(coords.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        vertexBuffer.put(coords).position(0);
        drawListBuffer = ByteBuffer.allocateDirect(indices.length * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
        drawListBuffer.put(indices).position(0);
    }

    public void draw(float[] mvpMatrix, float[] mvMatrix) {
        GLES20.glUseProgram(mProgram);
        mPositionHandle = GLES20.glGetAttribLocation(mProgram, "aPosition");
        GLES20.glEnableVertexAttribArray(mPositionHandle);
        GLES20.glVertexAttribPointer(mPositionHandle, 3, GLES20.GL_FLOAT, false, 12, vertexBuffer);
        mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_INT, drawListBuffer);
        GLES20.glDisableVertexAttribArray(mPositionHandle);
    }

    private int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        int[] compiled = new int[1];
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0);
        return shader;
    }
}