package com.proyectofinal;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Cube {
    private FloatBuffer vBuffer, nBuffer, tBuffer;
    private final int vertexCount = 36;

    public Cube(float w, float h, float d) {
        float x = w / 2, y = h / 2, z = d / 2;

        float[] v = {
                -x,-y, z,  x,-y, z, -x, y, z,   x,-y, z,  x, y, z, -x, y, z,
                -x,-y,-z, -x, y,-z,  x,-y,-z,   x,-y,-z, -x, y,-z,  x, y,-z,
                -x,-y,-z, -x,-y, z, -x, y,-z,  -x,-y, z, -x, y, z, -x, y,-z,
                x,-y,-z,  x, y,-z,  x,-y, z,    x,-y, z,  x, y,-z,  x, y, z,
                -x, y, z,  x, y, z, -x, y,-z,    x, y, z,  x, y,-z, -x, y,-z,
                -x,-y, z, -x,-y,-z,  x,-y, z,    x,-y, z, -x,-y,-z,  x,-y,-z
        };

        float[] n = {
                0,0,1, 0,0,1, 0,0,1, 0,0,1, 0,0,1, 0,0,1,
                0,0,-1, 0,0,-1, 0,0,-1, 0,0,-1, 0,0,-1, 0,0,-1,
                -1,0,0, -1,0,0, -1,0,0, -1,0,0, -1,0,0, -1,0,0,
                1,0,0, 1,0,0, 1,0,0, 1,0,0, 1,0,0, 1,0,0,
                0,1,0, 0,1,0, 0,1,0, 0,1,0, 0,1,0, 0,1,0,
                0,-1,0, 0,-1,0, 0,-1,0, 0,-1,0, 0,-1,0, 0,-1,0
        };

        float[] t = new float[vertexCount * 2];
        for (int i = 0; i < 6; i++) {
            int offset = i * 12;
            t[offset]   = 0.0f; t[offset+1] = 1.0f;
            t[offset+2] = 1.0f; t[offset+3] = 1.0f;
            t[offset+4] = 0.0f; t[offset+5] = 0.0f;
            t[offset+6] = 1.0f; t[offset+7] = 1.0f;
            t[offset+8] = 1.0f; t[offset+9] = 0.0f;
            t[offset+10]= 0.0f; t[offset+11]= 0.0f;
        }

        vBuffer = createFB(v);
        nBuffer = createFB(n);
        tBuffer = createFB(t);
    }

    private FloatBuffer createFB(float[] data) {
        ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(data);
        fb.position(0);
        return fb;
    }

    public void draw(float[] mvp, float[] mv, TextureShader shader, int texID) {
        GLES20.glUseProgram(shader.program);

        GLES20.glUniformMatrix4fv(shader.mvpH, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(shader.mvH, 1, false, mv, 0);

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texID);
        GLES20.glUniform1i(shader.texUnitH, 0);

        GLES20.glEnableVertexAttribArray(shader.posH);
        GLES20.glVertexAttribPointer(shader.posH, 3, GLES20.GL_FLOAT, false, 0, vBuffer);

        GLES20.glEnableVertexAttribArray(shader.normH);
        GLES20.glVertexAttribPointer(shader.normH, 3, GLES20.GL_FLOAT, false, 0, nBuffer);

        GLES20.glEnableVertexAttribArray(shader.texH);
        GLES20.glVertexAttribPointer(shader.texH, 2, GLES20.GL_FLOAT, false, 0, tBuffer);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);

        GLES20.glDisableVertexAttribArray(shader.posH);
        GLES20.glDisableVertexAttribArray(shader.normH);
        GLES20.glDisableVertexAttribArray(shader.texH);
    }
}
