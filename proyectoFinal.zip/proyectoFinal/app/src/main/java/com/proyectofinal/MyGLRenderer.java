package com.proyectofinal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import android.os.SystemClock;

public class MyGLRenderer implements GLSurfaceView.Renderer {
    private final Context context;

    private TextureShader textureShader;
    private int texPista, texCarro1, texCarro2;
    private Ejes ejes;
    private Terrain terreno;

    //BASE DEL CARRO
    public volatile float angle_c1 = -10.0f;
    private float altura_base = 1.45f;
    private Cylinder c1;
    private Cylinder c2;
    private Cylinder c3;
    private Cylinder c4;
    private Cylinder c5;
    private Cylinder c6;

    ///
    private Cylinder c12;
    private Cylinder c22;
    private Cylinder c32;
    private Cylinder c42;
    private Cylinder c52;
    private Cylinder c62;



    //Cabina
    private PyramidTruncade p1;
    private PyramidTruncade_2 p2; //ventana lados
    private PyramidTruncade_2 p3; //ventana alfernte y detras


    private PyramidTruncade p12;
    private PyramidTruncade_2 p22; //ventana lados
    private PyramidTruncade_2 p32; //ventana alfernte y detras


    //Chasis
    private Cube b1;
    private Cube b2;

    private Cube b12;
    private Cube b22;



    //Llantas
    private Torus l1;
    private Torus l2;
    private Torus l3;
    private Torus l4;

    private Torus l12;
    private Torus l22;
    private Torus l32;
    private Torus l42;


    //Aros
    private Sphere ar1;
    private Sphere ar2;
    private Sphere ar3;
    private Sphere ar4;

    private Sphere ar12;
    private Sphere ar22;
    private Sphere ar32;
    private Sphere ar42;


    private FogParticle humoEfecto;
    private int texHumo;
    private float angleN = 0.0f;
    ///////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////
    public volatile float angleX = 0.0f;
    public volatile float angleY = 0.0f;
    public volatile float camPosX = 0.0f;
    public volatile float camPosZ = 0.0f;
    public volatile float distancia = 5.0f;
    ///////////////////////////////////////////////////////

    private final float[] projectionMatrix = new float[16];
    private final float[] viewMatrix = new float[16];
    private final float[] mvpMatrix = new float[16];
    private final float[] mvMatrix = new float[16];
    private final float[] modelMatrix = new float[16];

    public MyGLRenderer(Context context) {
        this.context = context;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0f, 0f, 0f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        textureShader = new TextureShader();

        humoEfecto = new FogParticle();
        texHumo = loadTexture(context, R.drawable.nieve);

        texCarro1 = loadTexture(context, R.drawable.textura_azul);
        texCarro2 = loadTexture(context, R.drawable.textura_rojo);
        ejes = new Ejes();

        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.pistaf1);

        int size = bitmap.getWidth();
        float[] heights = new float[size * size];
        for (int z = 0; z < size; z++) {
            for (int x = 0; x < size; x++) {
                int pixel = bitmap.getPixel(x, z);
                float intensity = (Color.red(pixel) + Color.green(pixel) + Color.blue(pixel)) / 3.0f;
                heights[z * size + x] = (intensity / 255.0f) * 6.0f; // Escala de altura
            }
        }
        terreno = new Terrain(heights, size);
        bitmap.recycle();


        c1 = new Cylinder(3f, 3.0f, altura_base, 4);
        c2 = new Cylinder(3f, 3.0f, altura_base, 4);
        c3 = new Cylinder(2f, 2f, altura_base, 4);
        c4 = new Cylinder(2f, 2f, altura_base, 4);
        c5 = new Cylinder(3f, 3.0f, altura_base/2, 4);
        c6 = new Cylinder(3f, 3.0f, altura_base/2, 4);

        p1 = new PyramidTruncade(3.2f, 4.5f, 2f, 2.2f, 0.85f);
        p2 = new PyramidTruncade_2(3f, 3f, 2.1f, 1.3f, 0.3f);
        p3 = new PyramidTruncade_2(2.6f, 4.7f, 1.5f, 2.6f, 0.4f);

        b1 = new Cube(1.2f, altura_base, 4f);
        b2 = new Cube(1.5f, altura_base, 4f);

        l1 = new Torus();
        l2 = new Torus();
        l3 = new Torus();
        l4 = new Torus();

        ar1 = new Sphere(1f, 30, 2);
        ar2 = new Sphere(1f, 30, 2);
        ar3 = new Sphere(1f, 30, 2);
        ar4 = new Sphere(1f, 30, 2);


        //OTRO AUTO

        c12 = new Cylinder(3f, 3.0f, altura_base, 4);
        c22 = new Cylinder(3f, 3.0f, altura_base, 4);
        c32 = new Cylinder(2f, 2f, altura_base, 4);
        c42 = new Cylinder(2f, 2f, altura_base, 4);
        c52 = new Cylinder(3f, 3.0f, altura_base/2, 4);
        c62 = new Cylinder(3f, 3.0f, altura_base/2, 4);

        p12 = new PyramidTruncade(3.2f, 4.5f, 2f, 2.2f, 0.85f);
        p22 = new PyramidTruncade_2(3f, 3f, 2.1f, 1.3f, 0.3f);
        p32 = new PyramidTruncade_2(2.6f, 4.7f, 1.5f, 2.6f, 0.4f);

        b12 = new Cube(1.2f, altura_base, 4f);
        b22 = new Cube(1.5f, altura_base, 4f);

        l12 = new Torus();
        l22 = new Torus();
        l32 = new Torus();
        l42 = new Torus();

        ar12 = new Sphere(1f, 30, 2);
        ar22 = new Sphere(1f, 30, 2);
        ar32 = new Sphere(1f, 30, 2);
        ar42 = new Sphere(1f, 30, 2);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        if (angleX > 89.0f) angleX = 89.0f;
        if (angleX < 1.0f) angleX = 1.0f;

        float theta = (float) Math.toRadians(angleY);
        float phi = (float) Math.toRadians(angleX);

        float dX = (float) (distancia * Math.cos(phi) * Math.sin(theta));
        float dY = (float) (distancia * Math.sin(phi));
        float dZ = (float) (distancia * Math.cos(phi) * Math.cos(theta));

        float finalCamY = Math.max(dY, 0f);
        Matrix.setLookAtM(viewMatrix, 0,
                camPosX + dX, finalCamY, camPosZ + dZ,
                camPosX, 1.0f, camPosZ,
                0f, 1f, 0f);

        float posX = 0.0f;
        float posY = -2f;
        float posZ = -8.0f;
        angleN += 1.5f;

        for (int i = 0; i < 3; i++) {
            Matrix.setIdentityM(modelMatrix, 0);
            Matrix.scaleM(modelMatrix, 0, 15, 15f, 15f);
            Matrix.rotateM(modelMatrix, 0, (i * 60.0f) + angleN, 0, 1, 0);
            float[] tempMatrix = new float[16];
            Matrix.setIdentityM(tempMatrix, 0);
            Matrix.translateM(tempMatrix, 0, posX, posY, posZ);
            float[] finalModelMatrix = new float[16];
            Matrix.multiplyMM(finalModelMatrix, 0, tempMatrix, 0, modelMatrix, 0);
            Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, finalModelMatrix, 0);
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
            humoEfecto.draw(mvpMatrix, texHumo, 0.4f);
        }

        // TERRENO
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.scaleM(modelMatrix, 0, 0.02f, 0.02f, 0.02f);
        Matrix.rotateM(modelMatrix, 0, angle_c1, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0f, -300.0f, 0f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        terreno.draw(mvpMatrix, mvMatrix);

        // EJES
        float[] mModelMatrixEjes = new float[16];
        Matrix.setIdentityM(mModelMatrixEjes, 0);
        float[] mvMatrix_Ejes = new float[16];
        Matrix.multiplyMM(mvMatrix_Ejes, 0, viewMatrix, 0, mModelMatrixEjes, 0);
        float[] mVPMatrix_Ejes = new float[16];
        Matrix.multiplyMM(mVPMatrix_Ejes, 0, projectionMatrix, 0, mvMatrix_Ejes, 0);
        //ejes.draw(mVPMatrix_Ejes);

        /// ///////////////////////////////////////////////////////////////////////////////
        float offsetX = 4f;
        float offsetY = -5.5f;
        float offsetZ = -7.5f;

        // CUERPO
        // c1
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c1, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, -0.4f, 0f, 0.4f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c1.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // c2
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c1, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0.4f, 0f, -0.4f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c2.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // c3
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c1, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, -2f, 0f, 2f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c3.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // c4
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c1, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 2f, 0f, -2f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c4.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // c5
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c1, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 1.8f, 0.37f, -1.8f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c5.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // c6
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c1, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, -2.2f, 0.37f, 2.2f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c6.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // CABINA Y VENTANAS
        // p1
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.25f, 0.25f, 0.25f);
        Matrix.rotateM(modelMatrix, 0, angle_c1 - 45, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0f, 1f, -0.2f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        p1.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // p2
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.13f, 0.25f, 0.13f);
        Matrix.rotateM(modelMatrix, 0, angle_c1 - 45, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0f, 1f, -0.4f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        p2.draw(mvpMatrix, mvMatrix);

        // p3
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.13f, 0.25f, 0.13f);
        Matrix.rotateM(modelMatrix, 0, angle_c1 - 45, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0f, 0.85f, -0.4f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        p3.draw(mvpMatrix, mvMatrix);

        // PARACHOQUES
        // b1
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c1 - 135, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 4.8f, 0f, 0f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        b1.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // b2
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c1 - 135, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, -4.4f, 0f, 0f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        b2.draw(mvpMatrix, mvMatrix, textureShader, texCarro1);

        // LLANTAS
        // l1, l2, l3, l4
        float[][] llantaPos = {{-3.1f, -0.7f, 1.7f}, {-3.1f, -0.7f, -1.7f}, {3.1f, -0.7f, 1.7f}, {3.1f, -0.7f, -1.7f}};
        Torus[] llantas = {l1, l2, l3, l4};
        for (int i = 0; i < 4; i++) {
            Matrix.setIdentityM(modelMatrix, 0);
            Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
            Matrix.scaleM(modelMatrix, 0, 0.22f, 0.22f, 0.22f);
            Matrix.rotateM(modelMatrix, 0, angle_c1 + 45, 0, 1, 0);
            Matrix.translateM(modelMatrix, 0, llantaPos[i][0], llantaPos[i][1], llantaPos[i][2]);
            Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
            llantas[i].draw(mvpMatrix, mvMatrix);
        }

        // AROS
        // ar1, ar2, ar3, ar4
        float[][] aroPos = {{6.8f, -1.5f, 3.5f}, {-6.8f, -1.5f, 3.5f}, {6.8f, -1.5f, -3.5f}, {-6.8f, -1.5f, -3.5f}};
        Sphere[] aros = {ar1, ar2, ar3, ar4};
        for (int i = 0; i < 4; i++) {
            Matrix.setIdentityM(modelMatrix, 0);
            Matrix.translateM(modelMatrix, 0, offsetX, offsetY, offsetZ);
            Matrix.scaleM(modelMatrix, 0, 0.1f, 0.1f, 0.1f);
            Matrix.rotateM(modelMatrix, 0, angle_c1 + 45, 0, 1, 0);
            Matrix.translateM(modelMatrix, 0, aroPos[i][0], aroPos[i][1], aroPos[i][2]);
            Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
            aros[i].draw(mvpMatrix, mvMatrix);
        }

        /// ///////////////////////////////////////////////
        //OTRO CARRO
        float offsetX2 = -12f;
        float offsetY2 = -5.5f;
        float offsetZ2 = 2f;
        float angle_c2 = -50.0f;

        // CUERPO
        // c12
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c2, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, -0.4f, 0f, 0.4f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c12.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // c22
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c2, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0.4f, 0f, -0.4f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c22.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // c32
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c2, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, -2f, 0f, 2f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c32.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // c42
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c2, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 2f, 0f, -2f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c42.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // c52
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c2, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 1.8f, 0.37f, -1.8f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c52.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // c62
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c2, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, -2.2f, 0.37f, 2.2f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        c62.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // CABINA Y VENTANS
        // p12
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.25f, 0.25f, 0.25f);
        Matrix.rotateM(modelMatrix, 0, angle_c2 - 45, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0f, 1f, -0.2f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        p12.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // p22
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.13f, 0.25f, 0.13f);
        Matrix.rotateM(modelMatrix, 0, angle_c2 - 45, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0f, 1f, -0.4f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        p22.draw(mvpMatrix, mvMatrix);

        // p32
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.13f, 0.25f, 0.13f);
        Matrix.rotateM(modelMatrix, 0, angle_c2 - 45, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 0f, 0.85f, -0.4f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        p32.draw(mvpMatrix, mvMatrix);

        // PARACHOQUES
        // b12
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c2 - 135, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, 4.8f, 0f, 0f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        b12.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // b22
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
        Matrix.scaleM(modelMatrix, 0, 0.2f, 0.2f, 0.2f);
        Matrix.rotateM(modelMatrix, 0, angle_c2 - 135, 0, 1, 0);
        Matrix.translateM(modelMatrix, 0, -4.4f, 0f, 0f);
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        b22.draw(mvpMatrix, mvMatrix, textureShader, texCarro2);

        // LLANTAS
        // l12, l22, l32, l42
        float[][] llantaPos2 = {{-3.1f, -0.7f, 1.7f}, {-3.1f, -0.7f, -1.7f}, {3.1f, -0.7f, 1.7f}, {3.1f, -0.7f, -1.7f}};
        Torus[] llantas2 = {l12, l22, l32, l42};
        for (int i = 0; i < 4; i++) {
            Matrix.setIdentityM(modelMatrix, 0);
            Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
            Matrix.scaleM(modelMatrix, 0, 0.22f, 0.22f, 0.22f);
            Matrix.rotateM(modelMatrix, 0, angle_c2 + 45, 0, 1, 0);
            Matrix.translateM(modelMatrix, 0, llantaPos2[i][0], llantaPos2[i][1], llantaPos2[i][2]);
            Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
            llantas2[i].draw(mvpMatrix, mvMatrix);
        }

        // AROS
        // ar12, ar22, ar32, ar42
        float[][] aroPos2 = {{6.8f, -1.5f, 3.5f}, {-6.8f, -1.5f, 3.5f}, {6.8f, -1.5f, -3.5f}, {-6.8f, -1.5f, -3.5f}};
        Sphere[] aros2 = {ar12, ar22, ar32, ar42};
        for (int i = 0; i < 4; i++) {
            Matrix.setIdentityM(modelMatrix, 0);
            Matrix.translateM(modelMatrix, 0, offsetX2, offsetY2, offsetZ2);
            Matrix.scaleM(modelMatrix, 0, 0.1f, 0.1f, 0.1f);
            Matrix.rotateM(modelMatrix, 0, angle_c2 + 45, 0, 1, 0);
            Matrix.translateM(modelMatrix, 0, aroPos2[i][0], aroPos2[i][1], aroPos2[i][2]);
            Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
            aros2[i].draw(mvpMatrix, mvMatrix);
        }
    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        float ratio = (float) width / height;
        Matrix.frustumM(projectionMatrix, 0, -ratio, ratio, -1, 1, 2.5f, 1000f);
    }

    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }

    public static int loadTexture(final Context context, final int resourceId) {
        final int[] textureHandle = new int[1];
        GLES20.glGenTextures(1, textureHandle, 0);
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inScaled = false;
        final Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), resourceId, options);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureHandle[0]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
        bitmap.recycle();
        return textureHandle[0];
    }
}
