package com.proyectofinal;

import android.opengl.GLES20;

public class TextureShader {
    public int program;
    public int posH, texH, normH; 
    public int mvpH, mvH, colorH, texUnitH, lightPosH, viewPosH; 

    private final String vs =
            "uniform mat4 uMVPMatrix;" +
                    "uniform mat4 uMVMatrix;" +
                    "attribute vec4 vPosition;" +
                    "attribute vec3 vNormal;" +
                    "attribute vec2 vTexCoord;" +
                    "varying vec3 vFragPos;" +
                    "varying vec3 vNormalVec;" +
                    "varying vec2 aTexCoord;" +
                    "varying float vDist;" + 
                    "void main() {" +
                    "  vFragPos = vec3(uMVMatrix * vPosition);" +
                    "  vNormalVec = vec3(uMVMatrix * vec4(vNormal, 0.0));" +
                    "  aTexCoord = vTexCoord;" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "  vDist = gl_Position.w;" + 
                    "}";

    private final String fs =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "uniform sampler2D uTexture;" +
                    "uniform vec3 uLightPos;" +
                    "uniform vec3 uViewPos;" +
                    "varying vec3 vFragPos;" +
                    "varying vec3 vNormalVec;" +
                    "varying vec2 aTexCoord;" +
                    "varying float vDist;" + 
                    "void main() {" +
                    "    vec4 texColor = texture2D(uTexture, aTexCoord);" +
                    "    float ambientStrength = 0.3;" +
                    "    vec3 ambient = ambientStrength * vec3(1.0, 1.0, 1.0);" +
                    "    vec3 norm = normalize(vNormalVec);" +
                    "    vec3 lightDir = normalize(uLightPos - vFragPos);" +
                    "    float diff = max(dot(norm, lightDir), 0.0);" +
                    "    vec3 diffuse = diff * vec3(1.0, 1.0, 1.0);" +
                    "    vec3 viewDir = normalize(uViewPos - vFragPos);" +
                    "    vec3 reflectDir = reflect(-lightDir, norm);" +
                    "    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32.0);" +
                    "    vec3 specular = 0.5 * spec * vec3(1.0, 1.0, 1.0);" +
                    "    vec3 finalLighting = ambient + diffuse;" +
                    "    vec4 colorObjeto = vec4(finalLighting, 1.0) * texColor * vColor + vec4(specular, 0.0);" +
                    "    vec4 fogColor = vec4(0.95, 0.95, 1.0, 1.0);" +
                    "    float fogStart = 15.0;" +
                    "    float fogEnd = 45.0;" +
                    "    float fogFactor = clamp((fogEnd - vDist) / (fogEnd - fogStart), 0.0, 1.0);" +
                    "    gl_FragColor = mix(fogColor, colorObjeto, fogFactor);" +
                    "}";

    public TextureShader() {
        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vs);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fs);
        program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vertexShader);
        GLES20.glAttachShader(program, fragmentShader);
        GLES20.glLinkProgram(program);

        posH = GLES20.glGetAttribLocation(program, "vPosition");
        normH = GLES20.glGetAttribLocation(program, "vNormal");
        texH = GLES20.glGetAttribLocation(program, "vTexCoord");
        mvpH = GLES20.glGetUniformLocation(program, "uMVPMatrix");
        mvH = GLES20.glGetUniformLocation(program, "uMVMatrix");
        colorH = GLES20.glGetUniformLocation(program, "vColor");
        texUnitH = GLES20.glGetUniformLocation(program, "uTexture");
        lightPosH = GLES20.glGetUniformLocation(program, "uLightPos");
        viewPosH = GLES20.glGetUniformLocation(program, "uViewPos");
    }
}
