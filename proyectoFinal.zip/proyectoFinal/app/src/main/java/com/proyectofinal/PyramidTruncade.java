package com.proyectofinal;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class PyramidTruncade {
    private FloatBuffer vBuffer, nBuffer, tBuffer;
    private final int vertexCount = 30;

    public PyramidTruncade(float bW, float bD, float tW, float tD, float h) {
        float bw = bW / 2, bd = bD / 2, tw = tW / 2, td = tD / 2, hh = h / 2;
        float[] v = {
                // Cara Frontal
                -bw,-hh,bd,  bw,-hh,bd,  tw,hh,td,   tw,hh,td, -tw,hh,td, -bw,-hh,bd,
                // Cara Trasera
                -bw,-hh,-bd, -tw,hh,-td, tw,hh,-td,  tw,hh,-td, bw,-hh,-bd, -bw,-hh,-bd,
                // Cara Derecha
                bw,-hh,bd,  bw,-hh,-bd, tw,hh,-td,  tw,hh,-td, tw,hh,td,  bw,-hh,bd,
                // Cara Izquierda
                -bw,-hh,bd, -tw,hh,td, -tw,hh,-td,  -tw,hh,-td, -bw,-hh,-bd, -bw,-hh,bd,
                // Cara Superior (Tapa)
                -tw,hh,td,  tw,hh,td,  tw,hh,-td,   tw,hh,-td, -tw,hh,-td, -tw,hh,td
        };

        float[] n = {
                // Frontal
                0,0,1, 0,0,1, 0,0,1, 0,0,1, 0,0,1, 0,0,1,
                // Trasera
                0,0,-1, 0,0,-1, 0,0,-1, 0,0,-1, 0,0,-1, 0,0,-1,
                // Derecha
                1,0,0, 1,0,0, 1,0,0, 1,0,0, 1,0,0, 1,0,0,
                // Izquierda
                -1,0,0, -1,0,0, -1,0,0, -1,0,0, -1,0,0, -1,0,0,
                // Superior
                0,1,0, 0,1,0, 0,1,0, 0,1,0, 0,1,0, 0,1,0
        };

        float[] t = new float[v.length / 3 * 2];
        for (int i = 0; i < 5; i++) {
            int o = i * 12;
            t[o]=0; t[o+1]=1; t[o+2]=1; t[o+3]=1; t[o+4]=1; t[o+5]=0;
            t[o+6]=1; t[o+7]=0; t[o+8]=0; t[o+9]=0; t[o+10]=0; t[o+11]=1;
        }
        vBuffer = createFB(v);
        nBuffer = createFB(n);
        tBuffer = createFB(t);
    }

    private FloatBuffer createFB(float[] d) {
        FloatBuffer fb = ByteBuffer.allocateDirect(d.length * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer();
        fb.put(d);
        fb.position(0);
        return fb;
    }

    public void draw(float[] mvp, float[] mv, TextureShader shader, int texID) {
        GLES20.glUseProgram(shader.program);

        GLES20.glUniformMatrix4fv(shader.mvpH, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(shader.mvH, 1, false, mv, 0);
        GLES20.glUniform4f(shader.colorH, 1.0f, 1.0f, 1.0f, 1.0f);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texID);
        GLES20.glUniform1i(shader.texUnitH, 0);
        GLES20.glEnableVertexAttribArray(shader.posH);
        GLES20.glVertexAttribPointer(shader.posH, 3, GLES20.GL_FLOAT, false, 0, vBuffer);
        GLES20.glEnableVertexAttribArray(shader.normH);
        GLES20.glVertexAttribPointer(shader.normH, 3, GLES20.GL_FLOAT, false, 0, nBuffer);
        GLES20.glEnableVertexAttribArray(shader.texH);
        GLES20.glVertexAttribPointer(shader.texH, 2, GLES20.GL_FLOAT, false, 0, tBuffer);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);
        GLES20.glDisableVertexAttribArray(shader.posH);
        GLES20.glDisableVertexAttribArray(shader.normH);
        GLES20.glDisableVertexAttribArray(shader.texH);
    }
}