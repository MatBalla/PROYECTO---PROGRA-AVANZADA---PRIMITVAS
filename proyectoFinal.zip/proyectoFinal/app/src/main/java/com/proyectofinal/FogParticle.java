package com.proyectofinal;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class FogParticle {
    private FloatBuffer vBuffer, tBuffer;
    private int program;
    private int posH, texCoordH, mvpH, texUnitH, colorH;

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 vPosition;" +
                    "attribute vec2 vTexCoord;" +
                    "varying vec2 aTexCoord;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "  aTexCoord = vTexCoord;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform sampler2D uTexture;" +
                    "uniform vec4 vColor;" +
                    "varying vec2 aTexCoord;" +
                    "void main() {" +
                    "    vec4 texColor = texture2D(uTexture, aTexCoord);" +
                    "    float brightness = (texColor.r + texColor.g + texColor.b) / 3.0;" +
                    "    if(brightness < 0.4) discard;" +
                    "    float alpha = smoothstep(0.4, 0.8, brightness) * vColor.a;" +
                    "    gl_FragColor = vec4(texColor.rgb, alpha);" +
                    "}";

    public FogParticle() {
        float[] coords = {-1f,-1f,0f, 1f,-1f,0f, -1f,1f,0f, 1f,-1f,0f, 1f,1f,0f, -1f,1f,0f};
        float[] tex = {0f,1f, 1f,1f, 0f,0f, 1f,1f, 1f,0f, 0f,0f};
        vBuffer = createFloatBuffer(coords);
        tBuffer = createFloatBuffer(tex);

        int vs = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fs = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);
        program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vs);
        GLES20.glAttachShader(program, fs);
        GLES20.glLinkProgram(program);

        posH = GLES20.glGetAttribLocation(program, "vPosition");
        texCoordH = GLES20.glGetAttribLocation(program, "vTexCoord");
        mvpH = GLES20.glGetUniformLocation(program, "uMVPMatrix");
        texUnitH = GLES20.glGetUniformLocation(program, "uTexture");
        colorH = GLES20.glGetUniformLocation(program, "vColor");
    }

    public void draw(float[] mvp, int texID, float opacity) {
        GLES20.glUseProgram(program);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE);
        GLES20.glDepthMask(false);
        GLES20.glUniformMatrix4fv(mvpH, 1, false, mvp, 0);
        GLES20.glUniform4f(colorH, 1.0f, 1.0f, 1.0f, opacity);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texID);
        GLES20.glUniform1i(texUnitH, 0);
        GLES20.glEnableVertexAttribArray(posH);
        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, 0, vBuffer);
        GLES20.glEnableVertexAttribArray(texCoordH);
        GLES20.glVertexAttribPointer(texCoordH, 2, GLES20.GL_FLOAT, false, 0, tBuffer);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
        GLES20.glDepthMask(true);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    private FloatBuffer createFloatBuffer(float[] data) {
        ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(data);
        fb.position(0);
        return fb;
    }
}