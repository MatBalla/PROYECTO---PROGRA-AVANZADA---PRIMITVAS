package com.proyectofinal;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class PyramidTruncade_2 {

    private final FloatBuffer vertexBuffer;
    private final FloatBuffer normalBuffer;
    private final int mProgram;
    private int numVertices;

    public PyramidTruncade_2(float bottomSizeX, float bottomSizeZ, float topSizeX, float topSizeZ, float height) {
        float bhx = bottomSizeX ; // Base inferior Half X
        float bhz = bottomSizeZ ; // Base inferior Half Z
        float thx = topSizeX ;    // Base superior Half X
        float thz = topSizeZ ;    // Base superior Half Z
        float h = height ;        // altura

        float[] vertices = {
                // Cara Frontal
                -thx, h, thz,  -bhx, -h, bhz,   bhx, -h, bhz,   thx, h, thz,
                // Cara Trasera
                -thx, h, -thz,  thx, h, -thz,   bhx, -h, -bhz,  -bhx, -h, -bhz,
                // Cara Superior
                -thx, h, -thz, -thx, h, thz,    thx, h, thz,    thx, h, -thz,
                // Cara Inferior
                -bhx, -h, -bhz, bhx, -h, -bhz,  bhx, -h, bhz,  -bhx, -h, bhz,
                // Cara Derecha
                thx, h, thz,    bhx, -h, bhz,   bhx, -h, -bhz,  thx, h, -thz,
                // Cara Izquierda
                -thx, h, thz,  -thx, h, -thz,  -bhx, -h, -bhz, -bhx, -h, bhz
        };

        float[] normals = {
                0, 0.44f, 1,  0, 0.44f, 1,  0, 0.44f, 1,  0, 0.44f, 1, // Frontal
                0, 0.44f, -1, 0, 0.44f, -1, 0, 0.44f, -1, 0, 0.44f, -1, // Trasera
                0, 1, 0,      0, 1, 0,      0, 1, 0,      0, 1, 0,      // Superior
                0, -1, 0,     0, -1, 0,     0, -1, 0,     0, -1, 0,     // Inferior
                1, 0.44f, 0,  1, 0.44f, 0,  1, 0.44f, 0,  1, 0.44f, 0,  // Derecha
                -1, 0.44f, 0, -1, 0.44f, 0, -1, 0.44f, 0, -1, 0.44f, 0   // Izquierda
        };

        numVertices = vertices.length / 3;
        vertexBuffer = createFloatBuffer(vertices);
        normalBuffer = createFloatBuffer(normals);
        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);
        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    public void draw(float[] mvpMatrix, float[] mvMatrix) {
        GLES20.glUseProgram(mProgram);
        int posH = GLES20.glGetAttribLocation(mProgram, "vPosition");
        int normH = GLES20.glGetAttribLocation(mProgram, "vNormal");
        GLES20.glEnableVertexAttribArray(posH);
        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer);
        GLES20.glEnableVertexAttribArray(normH);
        GLES20.glVertexAttribPointer(normH, 3, GLES20.GL_FLOAT, false, 0, normalBuffer);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVPMatrix"), 1, false, mvpMatrix, 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVMatrix"), 1, false, mvMatrix, 0);
        GLES20.glUniform4f(GLES20.glGetUniformLocation(mProgram, "vColor"), 0.53f, 0.81f, 0.94f, 1.0f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "lightPosition"), 5.0f, 5.0f, 5.0f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "viewPosition"), 5.0f, 5.0f, 5.0f);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(mProgram, "shininess"), 32.0f);
        for (int i = 0; i < 6; i++) {
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, i * 4, 4);
        }
        GLES20.glDisableVertexAttribArray(posH);
        GLES20.glDisableVertexAttribArray(normH);
    }

    private FloatBuffer createFloatBuffer(float[] data) {
        ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(data).position(0);
        return fb;
    }

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix; uniform mat4 uMVMatrix;" +
                    "attribute vec4 vPosition; attribute vec3 vNormal;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  aPosition = vec3(uMVMatrix * vPosition);" +
                    "  aNormal = normalize(mat3(uMVMatrix) * vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float; uniform vec4 vColor; uniform vec3 lightPosition; uniform vec3 viewPosition; uniform float shininess;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  vec3 N = normalize(aNormal); vec3 L = normalize(lightPosition - aPosition);" +
                    "  float diff = max(dot(N, L), 0.0);" +
                    "  vec3 V = normalize(viewPosition - aPosition); vec3 R = reflect(-L, N);" +
                    "  float spec = pow(max(dot(V, R), 0.0), shininess);" +
                    "  vec4 ambient = 0.3 * vColor;" +
                    "  vec4 diffuse = diff * vColor;" +
                    "  gl_FragColor = ambient + diffuse + (vec4(1.0) * spec);" +
                    "}";
}