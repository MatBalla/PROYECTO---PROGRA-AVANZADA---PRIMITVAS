package com.iluminacionespecular;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

//La iluminacion especular depende de la posicion de la camara
//
public class MyGLRenderer implements GLSurfaceView.Renderer {
    private Cube cube;

    // Matrices de transformación
    private final float[] projectionMatrix = new float[16];
    private final float[] viewMatrix = new float[16];
    private final float[] mvpMatrix = new float[16];
    private final float[] mvMatrix = new float[16];
    private final float[] modelMatrix = new float[16];


    // Parámetros de cámara
    public float camaraX = 0f;
    public float camaraY = 0f;
    public float camaraZ = 5f;

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        // Fondo azul oscuro
        GLES20.glClearColor(0.0f, 0.1216f, 0.2471f, 1.0f);

        // Habilitar el buffer de profundidad (indispensable para 3D)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        cube = new Cube();
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        // Configurar la posición de la cámara
        Matrix.setLookAtM(
                viewMatrix, 0,
                camaraX, camaraY, camaraZ,
                0f, 0f, 0f,
                0f, 1f, 0f
        );

        Matrix.setIdentityM(modelMatrix, 0);

        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);

        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);

        cube.draw(mvpMatrix, mvMatrix);
    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        float ratio = (float) width / height;

        // Definir el volumen de visión
        Matrix.frustumM(projectionMatrix, 0,
                -ratio, ratio,
                -1, 1,
                2f, 10f);
    }

    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
}