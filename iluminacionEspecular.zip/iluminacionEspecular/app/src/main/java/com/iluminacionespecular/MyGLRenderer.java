package com.iluminacionespecular;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

//La iluminacion especular depende de la posicion de la camara
public class MyGLRenderer implements GLSurfaceView.Renderer {

    //Cubo
    private Cube cube;
    private float angle_cube = 0.0f;

    //Torus
    private Torus torus;
    private float angle_torus = 0.0f;

    //Cilindro
    private Cylinder cilindro;
    private float angle_cylinder = 0.0f;

    //Piramide
    private Piramide piramide;
    private float angle_piramide = 0.0f;

    //Cono
    private Cone cono;
    private float angle_cone = 0.0f;

    //Esfera
    private Sphere esfera;
    private float angle_sphere = 0.0f;

    //Piramide truncada
    private TruncatedPyramid piramide_truncada;
    private float angle_piramide_truncada = 0.0f;



    // Matrices de transformación
    private final float[] projectionMatrix = new float[16];
    private final float[] viewMatrix = new float[16];
    private final float[] mvpMatrix = new float[16];
    private final float[] mvMatrix = new float[16];
    private final float[] modelMatrix = new float[16];


    // Ver el cubo que se aplique la iluminación especular 1,1,5
    public float camaraX = 1f;
    public float camaraY = 1f;
    public float camaraZ = 5f;

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.0f, 0.1216f, 0.2471f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        cube = new Cube();
        torus = new Torus();
        cilindro = new Cylinder(1f, 1.5f, 30);
        piramide = new Piramide();
        cono = new Cone(1f, 2, 30);
        esfera = new Sphere(1.5f, 30, 30);
        piramide_truncada = new TruncatedPyramid();
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        Matrix.setLookAtM(
                viewMatrix, 0,
                camaraX, camaraY, camaraZ,
                0f, 0f, 0f,
                0f, 1f, 0f
        );

        //---------------------------------------------------------------------------
        //---------------------------------------------------------------------------
        //Cubo
        Matrix.setIdentityM(modelMatrix, 0);
        // 1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                modelMatrix, //Matriz modelo
                0,//indice
                0.7f,//x
                0.7f,//y
                0.7f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria

        Matrix.rotateM(
                modelMatrix,//Matriz modelo
                0, //indice
                angle_cube,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                modelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                0f,//y
                0f//z
        );
        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        cube.draw(mvpMatrix, mvMatrix);
        angle_cube += 1.0f;
        //---------------------------------------------------------------------------

        //---------------------------------------------------------------------------
        //TORUS
        Matrix.setIdentityM(modelMatrix, 0);
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                modelMatrix, //Matriz modelo
                0,//indice
                0.3f,//x
                0.3f,//y
                0.3f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                modelMatrix,//Matriz modelo
                0, //indice
                angle_torus,//angulo de rotacion
                0,//x - (0,1)
                0,//y - (0,1)
                1//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                modelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                -3f,//y
                0f//z
        );

        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        torus.draw(mvpMatrix, mvMatrix);
        angle_torus += 1.0f;
        //---------------------------------------------------------------------------

        //---------------------------------------------------------------------------
        //Cilindro
        Matrix.setIdentityM(modelMatrix, 0);
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                modelMatrix, //Matriz modelo
                0,//indice
                0.3f,//x
                0.3f,//y
                0.3f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                modelMatrix,//Matriz modelo
                0, //indice
                angle_cylinder,//angulo de rotacion
                0,//x - (0,1)
                0,//y - (0,1)
                1//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                modelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                -3f,//y
                0f//z
        );

        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        cilindro.draw(mvpMatrix, mvMatrix);
        angle_cylinder += 1.0f;
        //---------------------------------------------------------------------------

        //---------------------------------------------------------------------------
        //Piramide
        Matrix.setIdentityM(modelMatrix, 0);
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                modelMatrix, //Matriz modelo
                0,//indice
                0.3f,//x
                0.3f,//y
                0.3f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                modelMatrix,//Matriz modelo
                0, //indice
                angle_piramide,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                1//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                modelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                4f,//y
                0f//z
        );

        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        piramide.draw(mvpMatrix, mvMatrix);
        angle_piramide += 1.0f;
        //---------------------------------------------------------------------------

        //---------------------------------------------------------------------------
        //Cono
        Matrix.setIdentityM(modelMatrix, 0);
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                modelMatrix, //Matriz modelo
                0,//indice
                0.3f,//x
                0.3f,//y
                0.3f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                modelMatrix,//Matriz modelo
                0, //indice
                angle_cone,//angulo de rotacion
                0,//x - (0,1)
                1,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                modelMatrix, //Matriz modelo
                0,//indice
                3f,//x
                0f,//y
                3f//z
        );

        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        cono.draw(mvpMatrix, mvMatrix);
        angle_cone += 1.0f;
        //---------------------------------------------------------------------------

        //---------------------------------------------------------------------------
        //Esfera
        Matrix.setIdentityM(modelMatrix, 0);
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                modelMatrix, //Matriz modelo
                0,//indice
                0.3f,//x
                0.3f,//y
                0.3f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                modelMatrix,//Matriz modelo
                0, //indice
                angle_sphere,//angulo de rotacion
                1,//x - (0,1)
                0,//y - (0,1)
                0//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                modelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                0f,//y
                4f//z
        );

        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        esfera.draw(mvpMatrix, mvMatrix);
        angle_sphere += 1.0f;
        //---------------------------------------------------------------------------

        //---------------------------------------------------------------------------
        //Piramide Truncada
        Matrix.setIdentityM(modelMatrix, 0);
        //1-Scale (Escalado) - tamanio
        Matrix.scaleM(
                modelMatrix, //Matriz modelo
                0,//indice
                0.3f,//x
                0.3f,//y
                0.3f//z
        );

        //2-Rotate(Rotar) - giro alrededor de una línea imaginaria
        Matrix.rotateM(
                modelMatrix,//Matriz modelo
                0, //indice
                angle_piramide_truncada,//angulo de rotacion
                1,//x - (0,1)
                0,//y - (0,1)
                1//z - (0,1)
        );

        //3-Translate (Trasladar) - a donde se mueve en x,y,z como un punto
        Matrix.translateM(
                modelMatrix, //Matriz modelo
                0,//indice
                0f,//x
                1f,//y
                1f//z
        );

        Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0);
        //piramide_truncada.draw(mvpMatrix, mvMatrix);
        //angle_piramide_truncada += 1.0f;
        //---------------------------------------------------------------------------


    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        float ratio = (float) width / height;
        Matrix.frustumM(projectionMatrix, 0,
                -ratio, ratio,
                -1, 1,
                2f, 10f);
    }

    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
}