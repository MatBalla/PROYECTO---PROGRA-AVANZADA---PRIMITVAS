package com.iluminacionespecular;

import static com.iluminacionespecular.MyGLRenderer.loadShader;
import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Piramide {
    private final FloatBuffer vertexBuffer;
    private final FloatBuffer normalBuffer; // Buffer para normales
    private final int mProgram;
    static final int COORDS_POR_VERTEX = 3;

    // Para iluminación plana (flat shading), repetimos vértices por cada cara
    // para que cada una tenga su propia normal.
    static float[] vertices = {
            // Cara Frontal
            0.0f,  1.0f,  0.0f,  -1.0f, -1.0f,  1.0f,   1.0f, -1.0f,  1.0f,
            // Cara Derecha
            0.0f,  1.0f,  0.0f,   1.0f, -1.0f,  1.0f,   0.0f, -1.0f, -1.0f,
            // Cara Izquierda
            0.0f,  1.0f,  0.0f,   0.0f, -1.0f, -1.0f,  -1.0f, -1.0f,  1.0f,
            // Base (Cara inferior)
            -1.0f, -1.0f,  1.0f,   0.0f, -1.0f, -1.0f,   1.0f, -1.0f,  1.0f
    };

    // Calculamos las normales perpendiculares a cada cara
    static float[] normales = {
            // Frontal: (0, 0.44, 0.89) aprox.
            0.0f, 0.447f, 0.894f,  0.0f, 0.447f, 0.894f,  0.0f, 0.447f, 0.894f,
            // Derecha
            0.707f, 0.5f, -0.5f,   0.707f, 0.5f, -0.5f,   0.707f, 0.5f, -0.5f,
            // Izquierda
            -0.707f, 0.5f, -0.5f, -0.707f, 0.5f, -0.5f,  -0.707f, 0.5f, -0.5f,
            // Base (hacia abajo)
            0.0f, -1.0f, 0.0f,     0.0f, -1.0f, 0.0f,      0.0f, -1.0f, 0.0f
    };

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix; uniform mat4 uMVMatrix;" +
                    "attribute vec4 vPosition; attribute vec3 vNormal;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  aPosition = vec3(uMVMatrix * vPosition);" +
                    "  aNormal = normalize(mat3(uMVMatrix) * vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float; uniform vec4 vColor; uniform vec3 lightPosition;" +
                    "uniform vec3 viewPosition; uniform float shininees;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  vec3 N = normalize(aNormal); vec3 L = normalize(lightPosition - aPosition);" +
                    "  float diff = max(dot(N, L), 0.0);" +
                    "  vec3 V = normalize(viewPosition - aPosition); vec3 R = reflect(-L, N);" +
                    "  float spec = pow(max(dot(V, R), 0.0), shininees);" +
                    "  vec4 ambient = 0.3 * vColor;" +
                    "  vec4 diffuse = diff * vColor;" +
                    "  vec4 specular = vec4(1.0) * spec;" + // Brillo blanco
                    "  gl_FragColor = ambient + diffuse + specular;" +
                    "}";

    public Piramide() {
        // Buffer de vértices
        vertexBuffer = ByteBuffer.allocateDirect(vertices.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        vertexBuffer.put(vertices).position(0);

        // Buffer de normales
        normalBuffer = ByteBuffer.allocateDirect(normales.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        normalBuffer.put(normales).position(0);

        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    public void draw(float[] mvpMatrix, float[] mvMatrix) {
        GLES20.glUseProgram(mProgram);

        // Handles de posición y normales
        int posH = GLES20.glGetAttribLocation(mProgram, "vPosition");
        int normH = GLES20.glGetAttribLocation(mProgram, "vNormal");

        GLES20.glEnableVertexAttribArray(posH);
        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, 12, vertexBuffer);

        GLES20.glEnableVertexAttribArray(normH);
        GLES20.glVertexAttribPointer(normH, 3, GLES20.GL_FLOAT, false, 12, normalBuffer);

        // Matrices
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVPMatrix"), 1, false, mvpMatrix, 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVMatrix"), 1, false, mvMatrix, 0);

        // Color crema/beige
        GLES20.glUniform4f(GLES20.glGetUniformLocation(mProgram, "vColor"), 0.96f, 0.96f, 0.86f, 1.0f);

        // Iluminación (Consistente con tus otras figuras en 2,2,2)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "lightPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "viewPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(mProgram, "shininees"), 32.0f);

        // Dibujamos directamente con DrawArrays porque ya no usamos índices (duplicamos vértices)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertices.length / 3);

        GLES20.glDisableVertexAttribArray(posH);
        GLES20.glDisableVertexAttribArray(normH);
    }
}
