package com.iluminacionespecular;


import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

//MISMO CÓDIGO: TRIANGULO(2D) - - (1f, 2, 2)
//              PIRAMIDE(base 4 vertices) - (1f, 2, 4)
//              PIRAMIDE HEXAGONAL (base 6 vertices) - (1f, 2, 6)
//              TETRAEDRO(base 3 vertices) - (1f, 2, 3)
//              CONO(+30 vertices) - (1f, 2, +30)
public class Cone {
    private final FloatBuffer vertexBuffer;
    private final FloatBuffer normalBuffer; // Buffer para normales
    private int mProgram;

    static final int COORDS_POR_VERTEX = 3;
    private final int vertexStride = COORDS_POR_VERTEX * 4;

    float colorLados[] = {1.0f, 0.5f, 0.0f, 1.0f}; // Color naranja para ver mejor el brillo
    float colorBase[]  = {0.15f, 0.15f, 0.15f, 1.0f};

    private int sideVertexCount;
    private int baseStartIndex;
    private int baseVertexCount;

    public Cone(float radius, float height, int numPoints) {
        // Generamos coordenadas y normales
        Object[] data = createConeData(radius, height, numPoints);
        float[] coneCoords = (float[]) data[0];
        float[] coneNormals = (float[]) data[1];

        vertexBuffer = ByteBuffer.allocateDirect(coneCoords.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        vertexBuffer.put(coneCoords).position(0);

        normalBuffer = ByteBuffer.allocateDirect(coneNormals.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        normalBuffer.put(coneNormals).position(0);

        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    private Object[] createConeData(float radius, float height, int numPoints) {
        List<Float> coords = new ArrayList<>();
        List<Float> normals = new ArrayList<>();

        // --- LADOS DEL CONO (TRIANGLE_FAN) ---
        // Punta
        coords.add(0f); coords.add(height); coords.add(0f);
        normals.add(0f); normals.add(1f); normals.add(0f); // Normal hacia arriba en la punta

        double angleStep = 2.0 * Math.PI / numPoints;
        for (int i = 0; i <= numPoints; i++) {
            double ang = angleStep * i;
            float x = (float) (radius * Math.cos(ang));
            float z = (float) (radius * Math.sin(ang));
            coords.add(x); coords.add(0f); coords.add(z);

            // Normal lateral (hacia afuera)
            normals.add((float) Math.cos(ang));
            normals.add(0.5f); // Un poco de inclinación hacia arriba
            normals.add((float) Math.sin(ang));
        }
        sideVertexCount = numPoints + 2;

        // --- BASE DEL CONO (TRIANGLE_FAN) ---
        baseStartIndex = sideVertexCount;
        // Centro de la base
        coords.add(0f); coords.add(0f); coords.add(0f);
        normals.add(0f); normals.add(-1f); normals.add(0f); // Normal hacia abajo

        for (int i = 0; i <= numPoints; i++) {
            double ang = angleStep * i;
            coords.add((float) (radius * Math.cos(ang)));
            coords.add(0f);
            coords.add((float) (radius * Math.sin(ang)));
            normals.add(0f); normals.add(-1f); normals.add(0f);
        }
        baseVertexCount = numPoints + 2;

        float[] cArr = new float[coords.size()];
        for (int i = 0; i < coords.size(); i++) cArr[i] = coords.get(i);

        float[] nArr = new float[normals.size()];
        for (int i = 0; i < normals.size(); i++) nArr[i] = normals.get(i);

        return new Object[]{cArr, nArr};
    }

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix; uniform mat4 uMVMatrix;" +
                    "attribute vec4 vPosition; attribute vec3 vNormal;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  aPosition = vec3(uMVMatrix * vPosition);" +
                    "  aNormal = normalize(mat3(uMVMatrix) * vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float; uniform vec4 vColor; uniform vec3 lightPosition;" +
                    "uniform vec3 viewPosition; uniform float shininees;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  vec3 N = normalize(aNormal); vec3 L = normalize(lightPosition - aPosition);" +
                    "  float diff = max(dot(N, L), 0.0);" +
                    "  vec3 V = normalize(viewPosition - aPosition); vec3 R = reflect(-L, N);" +
                    "  float spec = pow(max(dot(V, R), 0.0), shininees);" +
                    "  vec4 ambient = 0.3 * vColor;" +
                    "  vec4 diffuse = diff * vColor;" +
                    "  vec4 specular = vec4(1.0) * spec;" +
                    "  gl_FragColor = ambient + diffuse + specular;" +
                    "}";

    public void draw(float[] mvpMatrix, float[] mvMatrix) {
        GLES20.glUseProgram(mProgram);

        int posH = GLES20.glGetAttribLocation(mProgram, "vPosition");
        int normH = GLES20.glGetAttribLocation(mProgram, "vNormal");

        GLES20.glEnableVertexAttribArray(posH);
        GLES20.glEnableVertexAttribArray(normH);

        // Pasar matrices
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVPMatrix"), 1, false, mvpMatrix, 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVMatrix"), 1, false, mvMatrix, 0);

        // Configuración de Luz (2,2,2)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "lightPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "viewPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(mProgram, "shininees"), 32.0f);

        int colorH = GLES20.glGetUniformLocation(mProgram, "vColor");

        // --- DIBUJAR LADOS ---
        GLES20.glUniform4fv(colorH, 1, colorLados, 0);
        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);
        GLES20.glVertexAttribPointer(normH, 3, GLES20.GL_FLOAT, false, vertexStride, normalBuffer);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, sideVertexCount);

        // --- DIBUJAR BASE ---
        GLES20.glUniform4fv(colorH, 1, colorBase, 0);
        // Desplazamos el puntero del buffer para la base
        vertexBuffer.position(baseStartIndex * 3);
        normalBuffer.position(baseStartIndex * 3);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, baseVertexCount);

        // Resetear posiciones de buffer
        vertexBuffer.position(0);
        normalBuffer.position(0);

        GLES20.glDisableVertexAttribArray(posH);
        GLES20.glDisableVertexAttribArray(normH);
    }
}
