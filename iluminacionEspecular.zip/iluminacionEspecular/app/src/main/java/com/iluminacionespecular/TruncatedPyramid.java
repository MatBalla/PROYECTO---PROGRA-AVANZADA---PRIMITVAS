package com.iluminacionespecular;


import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

//NO FUNCIONAAAA
public class TruncatedPyramid {

    private final FloatBuffer vertexBuffer;
    private final FloatBuffer normalBuffer;
    private final int mProgram;

    private static final float HALF_HEIGHT = 0.75f;
    private static final float TOP_S = 0.5f;
    private static final float BOTTOM_S = 1.0f;

    // Vértices duplicados para caras planas (necesario para normales correctas)
    private static final float[] FULL_VERTICES = {
            // Cara Frontal
            -TOP_S, HALF_HEIGHT, TOP_S, -BOTTOM_S, -HALF_HEIGHT, BOTTOM_S, BOTTOM_S, -HALF_HEIGHT, BOTTOM_S, TOP_S, HALF_HEIGHT, TOP_S,
            // Cara Trasera
            -TOP_S, HALF_HEIGHT, -TOP_S, TOP_S, HALF_HEIGHT, -TOP_S, BOTTOM_S, -HALF_HEIGHT, -BOTTOM_S, -BOTTOM_S, -HALF_HEIGHT, -BOTTOM_S,
            // Cara Superior
            -TOP_S, HALF_HEIGHT, -TOP_S, -TOP_S, HALF_HEIGHT, TOP_S, TOP_S, HALF_HEIGHT, TOP_S, TOP_S, HALF_HEIGHT, -TOP_S,
            // Cara Inferior
            -BOTTOM_S, -HALF_HEIGHT, -BOTTOM_S, BOTTOM_S, -HALF_HEIGHT, -BOTTOM_S, BOTTOM_S, -HALF_HEIGHT, BOTTOM_S, -BOTTOM_S, -HALF_HEIGHT, BOTTOM_S,
            // Cara Derecha
            TOP_S, HALF_HEIGHT, TOP_S, BOTTOM_S, -HALF_HEIGHT, BOTTOM_S, BOTTOM_S, -HALF_HEIGHT, -BOTTOM_S, TOP_S, HALF_HEIGHT, -TOP_S,
            // Cara Izquierda
            -TOP_S, HALF_HEIGHT, TOP_S, -TOP_S, HALF_HEIGHT, -TOP_S, -BOTTOM_S, -HALF_HEIGHT, -BOTTOM_S, -BOTTOM_S, -HALF_HEIGHT, BOTTOM_S
    };

    // Arreglo de Normales
    private static final float N_LAT = 0.447f;
    private static final float[] NORMALS = {
            0, N_LAT, 1,  0, N_LAT, 1,  0, N_LAT, 1,  0, N_LAT, 1,  // Frontal
            0, N_LAT, -1, 0, N_LAT, -1, 0, N_LAT, -1, 0, N_LAT, -1, // Trasera
            0, 1, 0,      0, 1, 0,      0, 1, 0,      0, 1, 0,      // Superior
            0, -1, 0,     0, -1, 0,     0, -1, 0,     0, -1, 0,      // Inferior
            1, N_LAT, 0,  1, N_LAT, 0,  1, N_LAT, 0,  1, N_LAT, 0,  // Derecha
            -1, N_LAT, 0, -1, N_LAT, 0, -1, N_LAT, 0, -1, N_LAT, 0  // Izquierda
    };

    public TruncatedPyramid() {
        vertexBuffer = createFloatBuffer(FULL_VERTICES);
        normalBuffer = createFloatBuffer(NORMALS);

        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    public void draw(float[] mvpMatrix, float[] mvMatrix) {
        GLES20.glUseProgram(mProgram);

        int posH = GLES20.glGetAttribLocation(mProgram, "vPosition");
        int normH = GLES20.glGetAttribLocation(mProgram, "vNormal");

        GLES20.glEnableVertexAttribArray(posH);
        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer);

        GLES20.glEnableVertexAttribArray(normH);
        GLES20.glVertexAttribPointer(normH, 3, GLES20.GL_FLOAT, false, 0, normalBuffer);

        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVPMatrix"), 1, false, mvpMatrix, 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVMatrix"), 1, false, mvMatrix, 0);

        // Ubicación de luz y cámara
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "lightPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "viewPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(mProgram, "shininess"), 10f); // Brillo más definido

        for (int i = 0; i < 6; i++) {
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, i * 4, 4);
        }

        GLES20.glDisableVertexAttribArray(posH);
        GLES20.glDisableVertexAttribArray(normH);
    }

    private FloatBuffer createFloatBuffer(float[] data) {
        ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(data).position(0);
        return fb;
    }

    // --- SHADERS MODIFICADOS: SOLO ESPECULAR ---
    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix; uniform mat4 uMVMatrix;" +
                    "attribute vec4 vPosition; attribute vec3 vNormal;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  aPosition = vec3(uMVMatrix * vPosition);" +
                    "  aNormal = normalize(mat3(uMVMatrix) * vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float; uniform vec3 lightPosition; uniform vec3 viewPosition; uniform float shininess;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  vec3 N = normalize(aNormal); " +
                    "  vec3 L = normalize(lightPosition - aPosition);" +
                    "  vec3 V = normalize(viewPosition - aPosition);" +
                    "  vec3 R = reflect(-L, N);" + // Vector de reflexión
                    "  " +
                    "  // Cálculo puramente especular" +
                    "  float spec = pow(max(dot(V, R), 0.0), shininess);" +
                    "  vec4 specularColor = vec4(1.0, 1.0, 1.0, 1.0);" + // El brillo será blanco
                    "  " +
                    "  gl_FragColor = specularColor * spec;" +
                    "}";
}