package com.iluminacionespecular;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Cube {
    private FloatBuffer normalBuffer;
    private FloatBuffer vertexBuffer;
    private ShortBuffer shortBuffer;
    private int mProgram;

    private final int vertexStride = COORDS_PER_VERTEX * 4;
    float color[] = {1.0f, 0.7137f, 0.7568f, 1.0f};

    static final int COORDS_PER_VERTEX = 3;
    static float cubeCoords[] = {
            -0.5f,  0.5f,  0.5f,   // 0: top-left front
            -0.5f, -0.5f,  0.5f,   // 1: bottom-left front
            0.5f, -0.5f,  0.5f,   // 2: bottom-right front
            0.5f,  0.5f,  0.5f,   // 3: top-right front
            -0.5f,  0.5f, -0.5f,   // 4: top-left back
            -0.5f, -0.5f, -0.5f,   // 5: bottom-left back
            0.5f, -0.5f, -0.5f,   // 6: bottom-right back
            0.5f,  0.5f, -0.5f    // 7: top-right back
    };

    private final short drawOrder[] = {
            0, 1, 2, 0, 2, 3, // Front
            4, 5, 6, 4, 6, 7, // Back
            0, 1, 5, 0, 5, 4, // Left
            3, 2, 6, 3, 6, 7, // Right
            0, 3, 7, 0, 7, 4, // Top
            1, 2, 6, 1, 6, 5  // Bottom
    };

    static float[] normals = {
            0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1,     //front
            0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, //back
            -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, //left
            1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0,     //right
            0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0,     //top
            0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0  //botton
    };

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
            "uniform mat4 uMVMatrix;" +
            "attribute vec4 vPosition;" +
            "attribute vec3 vNormal;" +
            "varying vec3 aNormal;" +
            "varying vec3 aPosition;" +
                    "void main() {" +
                    "aPosition = vec3(uMVMatrix * vPosition);" +
                    "aNormal = normalize(mat3(uMVMatrix)*vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
            "uniform vec4 vColor;" +
            "uniform vec3 lightPosition;" +
            "uniform vec3 viewPosition;" +
            "uniform float shininees;"+
            "varying vec3 aNormal;" +
            "varying vec3 aPosition;" +
                    "void main() {" +
                    "vec3 N = normalize(aNormal);" +
                    "vec3 L = normalize(lightPosition-aPosition);" +
                    "vec3 V = normalize(viewPosition-aPosition);" +
                    "vec3 R = reflect(-L,N);" +
                    "float spec = pow(max(dot(V,R), 0.0), shininees);" +
                    "vec4 specular = vColor*spec;" +
                    "  gl_FragColor = specular;" +
                    "}";

    public Cube() {
        // Buffer de vértices
        ByteBuffer bb = ByteBuffer.allocateDirect(cubeCoords.length * 4);
        bb.order(ByteOrder.nativeOrder());
        vertexBuffer = bb.asFloatBuffer();
        vertexBuffer.put(cubeCoords);
        vertexBuffer.position(0);

        //Buffer normales
        ByteBuffer nb = ByteBuffer.allocateDirect(normals.length * 4);
        nb.order(ByteOrder.nativeOrder());
        normalBuffer = nb.asFloatBuffer();
        normalBuffer.put(normals);
        normalBuffer.position(0);

        // Buffer de índices
        ByteBuffer dlb = ByteBuffer.allocateDirect(drawOrder.length * 2);
        dlb.order(ByteOrder.nativeOrder());
        shortBuffer = dlb.asShortBuffer();
        shortBuffer.put(drawOrder);
        shortBuffer.position(0);

        // Preparar Shaders
        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    public void draw(float[] mvpMatrix, float [] mvMatrix) {
        GLES20.glUseProgram(mProgram);

        // Obtener y configurar vPosition
        int positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, COORDS_PER_VERTEX,
                GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);

        //normales
        int normHandle = GLES20.glGetAttribLocation(mProgram, "vNormal");
        GLES20.glEnableVertexAttribArray(normHandle);
        GLES20.glVertexAttribPointer(normHandle, COORDS_PER_VERTEX,
                GLES20.GL_FLOAT, false, 0, normalBuffer);

        // Obtener y configurar uMVPMatrix
        int mvpHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0);

        int mvHandle = GLES20.glGetUniformLocation(mProgram, "uMVMatrix");
        GLES20.glUniformMatrix4fv(mvHandle, 1, false, mvMatrix, 0);

        // Obtener y configurar vColor
        int colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        //Confoiguracion posicion de la luz
        int lightHandle = GLES20.glGetUniformLocation(mProgram, "lightPosition");
        GLES20.glUniform3f(lightHandle, 0f, 0f, 3f);

        //Posicion del observador - misma camara en x,y,z del MyGLRenderer
        int viewHandle = GLES20.glGetUniformLocation(mProgram, "viewPosition");
        GLES20.glUniform3f(viewHandle, 0f, 0f, 5f);

        //Brillo suave 4f, brillo maximo 256
        int shinHandle = GLES20.glGetUniformLocation(mProgram, "shininees");
        GLES20.glUniform1f(shinHandle, 256f);

        // Dibujar elementos (triángulos por índices)
        GLES20.glDrawElements(
                GLES20.GL_TRIANGLES, drawOrder.length,
                GLES20.GL_UNSIGNED_SHORT, shortBuffer);

        GLES20.glDisableVertexAttribArray(positionHandle);
    }
}