package com.iluminacionespecular;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;

//MISMO CÓDIGO: CUADRADO(2D) - (1f, 1.5f, 2)
//              CUBO(1f, 1.5f, 4)
//              PRISMA TRIANGULAR(1f, 1.5f, 4)
//              CILINDRO (1f, 1.5f, +30)
public class Cylinder {

    private FloatBuffer bottomBuffer, topBuffer, sideBuffer;
    private FloatBuffer bottomNormalBuffer, topNormalBuffer, sideNormalBuffer; // Nuevos buffers para normales

    private int bottomCount, topCount, sideCount;
    private int mProgram;

    static final int COORDS_PER_VERTEX = 3;
    static final int STRIDE = COORDS_PER_VERTEX * 4;

    // Shaders actualizados para iluminación
    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix; uniform mat4 uMVMatrix;" +
                    "attribute vec4 vPosition; attribute vec3 vNormal;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  aPosition = vec3(uMVMatrix * vPosition);" +
                    "  aNormal = normalize(mat3(uMVMatrix) * vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float; uniform vec4 vColor; uniform vec3 lightPosition;" +
                    "uniform vec3 viewPosition; uniform float shininees;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  vec3 N = normalize(aNormal); vec3 L = normalize(lightPosition - aPosition);" +
                    "  float diff = max(dot(N, L), 0.0);" +
                    "  vec3 V = normalize(viewPosition - aPosition); vec3 R = reflect(-L, N);" +
                    "  float spec = pow(max(dot(V, R), 0.0), shininees);" +
                    "  vec4 ambient = 0.3 * vColor;" +
                    "  vec4 diffuse = diff * vColor;" +
                    "  vec4 specular = vec4(1.0) * spec;" +
                    "  gl_FragColor = ambient + diffuse + specular;" +
                    "}";

    public Cylinder(float radius, float height, int segments) {
        createBottom(radius, height, segments);
        createTop(radius, height, segments);
        createSide(radius, height, segments);

        int vs = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fs = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vs);
        GLES20.glAttachShader(mProgram, fs);
        GLES20.glLinkProgram(mProgram);
    }

    private void createBottom(float r, float h, int seg) {
        ArrayList<Float> vList = new ArrayList<>();
        ArrayList<Float> nList = new ArrayList<>();
        float y = -h / 2f;

        // Centro
        vList.add(0f); vList.add(y); vList.add(0f);
        nList.add(0f); nList.add(-1f); nList.add(0f); // Normal hacia abajo

        for (int i = 0; i <= seg; i++) {
            double ang = 2 * Math.PI * i / seg;
            vList.add((float)(r * Math.cos(ang))); vList.add(y); vList.add((float)(r * Math.sin(ang)));
            nList.add(0f); nList.add(-1f); nList.add(0f);
        }
        bottomCount = vList.size() / 3;
        bottomBuffer = toBuffer(vList);
        bottomNormalBuffer = toBuffer(nList);
    }

    private void createTop(float r, float h, int seg) {
        ArrayList<Float> vList = new ArrayList<>();
        ArrayList<Float> nList = new ArrayList<>();
        float y = h / 2f;

        vList.add(0f); vList.add(y); vList.add(0f);
        nList.add(0f); nList.add(1f); nList.add(0f); // Normal hacia arriba

        for (int i = 0; i <= seg; i++) {
            double ang = 2 * Math.PI * i / seg;
            vList.add((float)(r * Math.cos(ang))); vList.add(y); vList.add((float)(r * Math.sin(ang)));
            nList.add(0f); nList.add(1f); nList.add(0f);
        }
        topCount = vList.size() / 3;
        topBuffer = toBuffer(vList);
        topNormalBuffer = toBuffer(nList);
    }

    private void createSide(float r, float h, int seg) {
        ArrayList<Float> vList = new ArrayList<>();
        ArrayList<Float> nList = new ArrayList<>();
        float y1 = -h / 2f;
        float y2 = h / 2f;

        for (int i = 0; i <= seg; i++) {
            double ang = 2 * Math.PI * i / seg;
            float x = (float)(r * Math.cos(ang));
            float z = (float)(r * Math.sin(ang));

            // Vértice inferior y superior
            vList.add(x); vList.add(y1); vList.add(z);
            vList.add(x); vList.add(y2); vList.add(z);

            // Normal lateral (punta hacia afuera del eje central)
            float nx = (float)Math.cos(ang);
            float nz = (float)Math.sin(ang);
            nList.add(nx); nList.add(0f); nList.add(nz);
            nList.add(nx); nList.add(0f); nList.add(nz);
        }
        sideCount = vList.size() / 3;
        sideBuffer = toBuffer(vList);
        sideNormalBuffer = toBuffer(nList);
    }

    public void draw(float[] mvpMatrix, float[] mvMatrix) {
        GLES20.glUseProgram(mProgram);

        int posH = GLES20.glGetAttribLocation(mProgram, "vPosition");
        int normH = GLES20.glGetAttribLocation(mProgram, "vNormal");
        int mvpH = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        int mvH = GLES20.glGetUniformLocation(mProgram, "uMVMatrix");
        int colorH = GLES20.glGetUniformLocation(mProgram, "vColor");
        int lightH = GLES20.glGetUniformLocation(mProgram, "lightPosition");
        int viewH = GLES20.glGetUniformLocation(mProgram, "viewPosition");
        int shinH = GLES20.glGetUniformLocation(mProgram, "shininees");

        GLES20.glUniformMatrix4fv(mvpH, 1, false, mvpMatrix, 0);
        GLES20.glUniformMatrix4fv(mvH, 1, false, mvMatrix, 0);
        GLES20.glUniform3f(lightH, 2.0f, 2.0f, 2.0f);
        GLES20.glUniform3f(viewH, 2.0f, 2.0f, 2.0f);
        GLES20.glUniform1f(shinH, 32.0f);

        GLES20.glEnableVertexAttribArray(posH);
        GLES20.glEnableVertexAttribArray(normH);

        // --- Dibujar Tapas ---
        GLES20.glUniform4f(colorH, 0.2f, 0.2f, 0.2f, 1.0f);

        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, STRIDE, bottomBuffer);
        GLES20.glVertexAttribPointer(normH, 3, GLES20.GL_FLOAT, false, STRIDE, bottomNormalBuffer);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, bottomCount);

        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, STRIDE, topBuffer);
        GLES20.glVertexAttribPointer(normH, 3, GLES20.GL_FLOAT, false, STRIDE, topNormalBuffer);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, topCount);

        // --- Dibujar Lateral ---
        GLES20.glUniform4f(colorH, 0.8f, 0.1f, 0.1f, 1.0f); // Rojo para notar el brillo
        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, STRIDE, sideBuffer);
        GLES20.glVertexAttribPointer(normH, 3, GLES20.GL_FLOAT, false, STRIDE, sideNormalBuffer);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, sideCount);

        GLES20.glDisableVertexAttribArray(posH);
        GLES20.glDisableVertexAttribArray(normH);
    }

    private FloatBuffer toBuffer(ArrayList<Float> list) {
        float[] a = new float[list.size()];
        for (int i = 0; i < list.size(); i++) a[i] = list.get(i);
        ByteBuffer bb = ByteBuffer.allocateDirect(a.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(a).position(0);
        return fb;
    }
}