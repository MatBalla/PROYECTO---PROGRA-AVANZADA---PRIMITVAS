package com.iluminacionespecular;

import android.opengl.GLES20;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.List;

//MISMO CÓDIGO: CIRCULO(2D) - (1.5f, 30, 2)
//              ESFERA(1.5f, 30, 30)
//              FIGURAS VISTAS PERO REDONDEADAS - CUBO(ALMOHADA), etc.
public class Sphere {

    private FloatBuffer vertexBuffer;
    private FloatBuffer normalBuffer; // Arreglo de normales
    private ShortBuffer indexBuffer;
    private final int mProgram;

    private int indexCount;
    private final int vertexStride = 3 * 4;
    private float[] color = {0.60f, 0.70f, 0.80f, 1.0f};

    public Sphere(float radius, int stacks, int slices) {
        // Generar datos
        float[] vertices = createSphereVertices(radius, stacks, slices);
        float[] normals = createSphereNormals(stacks, slices); // Creamos el arreglo de normales
        short[] indices = createSphereIndices(stacks, slices);

        indexCount = indices.length;

        // Crear Buffers
        vertexBuffer = createFloatBuffer(vertices);
        normalBuffer = createFloatBuffer(normals);
        indexBuffer = createShortBuffer(indices);

        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);
        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    // Cálculo de Normales: En una esfera, la normal es el vector unitario de la posición
    private float[] createSphereNormals(int stacks, int slices) {
        List<Float> normals = new ArrayList<>();
        for (int i = 0; i <= stacks; i++) {
            double phi = Math.PI * i / stacks;
            for (int j = 0; j <= slices; j++) {
                double theta = 2.0 * Math.PI * j / slices;
                // Una normal unitaria (radio 1)
                normals.add((float) (Math.sin(phi) * Math.cos(theta))); // nx
                normals.add((float) (Math.cos(phi)));                  // ny
                normals.add((float) (Math.sin(phi) * Math.sin(theta))); // nz
            }
        }
        float[] normalArray = new float[normals.size()];
        for (int i = 0; i < normals.size(); i++) normalArray[i] = normals.get(i);
        return normalArray;
    }

    public void draw(float[] mvpMatrix, float[] mvMatrix) {
        GLES20.glUseProgram(mProgram);

        // Atributos
        int posH = GLES20.glGetAttribLocation(mProgram, "vPosition");
        GLES20.glEnableVertexAttribArray(posH);
        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);

        int normH = GLES20.glGetAttribLocation(mProgram, "vNormal");
        GLES20.glEnableVertexAttribArray(normH);
        GLES20.glVertexAttribPointer(normH, 3, GLES20.GL_FLOAT, false, vertexStride, normalBuffer);

        // Uniforms
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVPMatrix"), 1, false, mvpMatrix, 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVMatrix"), 1, false, mvMatrix, 0);
        GLES20.glUniform4fv(GLES20.glGetUniformLocation(mProgram, "vColor"), 1, color, 0);

        // Iluminación (Posición 2, 2, 2)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "lightPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "viewPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(mProgram, "shininees"), 64.0f); // Esfera más brillante

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, indexBuffer);

        GLES20.glDisableVertexAttribArray(posH);
        GLES20.glDisableVertexAttribArray(normH);
    }

    // --- MÉTODOS AUXILIARES ---
    private FloatBuffer createFloatBuffer(float[] data) {
        ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4).order(ByteOrder.nativeOrder());
        FloatBuffer buffer = bb.asFloatBuffer();
        buffer.put(data).position(0);
        return buffer;
    }

    private ShortBuffer createShortBuffer(short[] data) {
        ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 2).order(ByteOrder.nativeOrder());
        ShortBuffer buffer = bb.asShortBuffer();
        buffer.put(data).position(0);
        return buffer;
    }

    private float[] createSphereVertices(float radius, int stacks, int slices) {
        List<Float> coords = new ArrayList<>();
        for (int i = 0; i <= stacks; i++) {
            double phi = Math.PI * i / stacks;
            for (int j = 0; j <= slices; j++) {
                double theta = 2.0 * Math.PI * j / slices;
                coords.add((float) (radius * Math.sin(phi) * Math.cos(theta)));
                coords.add((float) (radius * Math.cos(phi)));
                coords.add((float) (radius * Math.sin(phi) * Math.sin(theta)));
            }
        }
        float[] res = new float[coords.size()];
        for(int i=0; i<coords.size(); i++) res[i] = coords.get(i);
        return res;
    }

    private short[] createSphereIndices(int stacks, int slices) {
        List<Short> indexList = new ArrayList<>();
        for (int i = 0; i < stacks; i++) {
            for (int j = 0; j < slices; j++) {
                int first = (i * (slices + 1)) + j;
                int second = first + slices + 1;
                indexList.add((short) first); indexList.add((short) second); indexList.add((short) (first + 1));
                indexList.add((short) (first + 1)); indexList.add((short) second); indexList.add((short) (second + 1));
            }
        }
        short[] res = new short[indexList.size()];
        for(int i=0; i<indexList.size(); i++) res[i] = indexList.get(i);
        return res;
    }

    // --- SHADERS ---
    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix; uniform mat4 uMVMatrix;" +
                    "attribute vec4 vPosition; attribute vec3 vNormal;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  aPosition = vec3(uMVMatrix * vPosition);" +
                    "  aNormal = normalize(mat3(uMVMatrix) * vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float; uniform vec4 vColor; uniform vec3 lightPosition;" +
                    "uniform vec3 viewPosition; uniform float shininees;" +
                    "varying vec3 aNormal; varying vec3 aPosition;" +
                    "void main() {" +
                    "  vec3 N = normalize(aNormal); vec3 L = normalize(lightPosition - aPosition);" +
                    "  float diff = max(dot(N, L), 0.0);" +
                    "  vec3 V = normalize(viewPosition - aPosition); vec3 R = reflect(-L, N);" +
                    "  float spec = pow(max(dot(V, R), 0.0), shininees);" +
                    "  gl_FragColor = (0.3 * vColor) + (diff * vColor) + (vec4(1.0) * spec);" +
                    "}";
}
