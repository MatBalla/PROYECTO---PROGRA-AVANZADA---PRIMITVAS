package com.prograavanzada.practicaeri;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {

    //puntos y lineas
    private Point point;
    private Point2 point2;
    private Point3 point3;
    private Line line; //instancia clase linea
    private Line2 line2;


    //lineas referencia plano x y y
    private LineaReferencia lineaRefrencia;
    private LineaReferenciaY lineaReferenciaY;

    //triangulo
    private Triangle triangulo;
    private Triangle2 triangulo2;
    private Triangle3 triangulo3;
    private Triangle4 triangulo4;

    //cuadrado
    private Square cuadrado;
    private Square2 cuadrado2;
    private Square3 cuadrado3;
    private Square4 cuadrado4;

    //circulo
    private Circle circulo;
    private Circle2 circulo2;
    private Circle3 circulo3;
    private Circle4 circulo4;

    //cilindro

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

        //carita feliz con baston
        //line.draw();
        //point3.draw();
        //line2.draw();

        //lineas referencia plano x y y - comentar para ejcutar linea normales
        //lineaRefrencia.draw();
        //lineaReferenciaY.draw();

        //trangulo


        //cuadrado
        cuadrado.draw();
        cuadrado2.draw();
        cuadrado3.draw();
        point.draw();
        point2.draw();
        cuadrado4.draw();
        triangulo.draw();
        triangulo2.draw();
        triangulo3.draw();
        triangulo4.draw();


        //circulo
        circulo.draw();
        circulo2.draw();
        circulo3.draw();
        circulo4.draw();


    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0,0,width,height);
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.1961f, 0.2941f, 0.4667f, 1.0f) ;

        //puntos y lineas
        //line = new Line();
       // point3 = new Point3();
        //line2 = new Line2();


        //lineas referencia plano x y y
        lineaRefrencia = new LineaReferencia();
        lineaReferenciaY = new LineaReferenciaY();

        //triangulo

        //cuadrado
        cuadrado = new Square();
        cuadrado2 = new Square2();
        cuadrado3 = new Square3();
        point = new Point();
        point2 = new Point2();
        cuadrado4 = new Square4();
        triangulo = new Triangle();
        triangulo2 = new Triangle2();
        triangulo3 = new Triangle3();
        triangulo4 = new Triangle4();

        //circulo
        circulo = new Circle(0.25f, 50);//radio, numero de puntos
        circulo2 = new Circle2(0.25f, 50);//radio, numero de puntos
        circulo3 = new Circle3(0.1f, 50);//radio, numero de puntos
        circulo4 = new Circle4(0.1f, 50);//radio, numero de puntos



    }



    //para cargar el shader vertex o el shader fragment (tipo de shader, código del shader em GLSL)
    public static int loadShader(int type, String shaderCode){
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        //compilar el shader
        GLES20.glCompileShader(shader);
        //retorna el id del shader
        return shader;

    }
}
