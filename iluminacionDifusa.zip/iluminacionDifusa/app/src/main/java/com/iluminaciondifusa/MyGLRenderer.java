package com.iluminaciondifusa;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {
    private Cube cube;

    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    private final float[] vpMatrix = new float[16];
    private final float[] mvMatrix = new float[16]; //normales

    // Parámetros de cámara
    //SI QUIERES VER TIPO PLANO DIBUJO: X=2, Y=2, Z=2
    public float camaraX = 2.5f;
    public float camaraY = 2.5f;
    public float camaraZ = 2.5f;


    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        Matrix.setLookAtM(
                mViewMatrix, 0,
                camaraX, camaraY, camaraZ,   // Posición de cámara
                0f, 0f, 0f,                  // Siempre mira al centro
                0f, 1f, 0f                   // Vector "arriba" (eje Y)
        );


        Matrix.multiplyMM(vpMatrix, 0, mProjectionMatrix,0, mViewMatrix, 0);

        float [] modelMatrix = new float[16];

        Matrix.setIdentityM(modelMatrix, 0);

        Matrix.multiplyMM(mvMatrix, 0 , mViewMatrix, 0, modelMatrix, 0);

        cube.draw(vpMatrix,mvMatrix);




    }


    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.20f, 0.23f, 0.25f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        cube = new Cube();

    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0,0,width,height);
        float ratio = (float) width / height;

        Matrix.frustumM(
                mProjectionMatrix, 0,
                -ratio, ratio,
                -1, 1,
                2f, 10f
        );
    }

    //para cargar el shader vertex o el shader fragment (tipo de shader, código del shader em GLSL)
    public static int loadShader(int type, String shaderCode){
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        //compilar el shader
        GLES20.glCompileShader(shader);
        //retorna el id del shader
        return shader;

    }
}

