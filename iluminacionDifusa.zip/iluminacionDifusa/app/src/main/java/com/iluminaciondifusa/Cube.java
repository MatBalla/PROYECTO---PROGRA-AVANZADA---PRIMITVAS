package com.iluminaciondifusa;
import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.nio.ShortBuffer;

public class Cube  {


    private FloatBuffer vertexBuffer;
    private FloatBuffer normalBuffer;
    private ShortBuffer shortBuffer;
    private int mProgram;


    // Datos extraídos de tus fotos
    static final int COORDS_PER_VERTEX = 3;
    static float cubeCoords[] = {
            -0.5f, 0.5f, 0.5f,   // 0: top-left front
            -0.5f, -0.5f, 0.5f,   // 1: bottom-left front
            0.5f, -0.5f, 0.5f,   // 2: bottom-right front
            0.5f, 0.5f, 0.5f,   // 3: top-right front
            -0.5f, 0.5f, -0.5f,   // 4: top-left back
            -0.5f, -0.5f, -0.5f,   // 5: bottom-left back
            0.5f, -0.5f, -0.5f,   // 6: bottom-right back
            0.5f, 0.5f, -0.5f    // 7: top-right back
    };

    // Orden de dibujo basado en tu foto (2 triángulos por cara)
    private final short drawOrder[] = {
            0, 1, 2, 0, 2, 3, // Front
            4, 5, 6, 4, 6, 7, // Back
            0, 1, 5, 0, 5, 4, // Left
            3, 2, 6, 3, 6, 7, // Right
            0, 3, 7, 0, 7, 4, // Top
            1, 2, 6, 1, 6, 5  // Bottom
    };

    static float[] normals = {
            0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1,     //front
            0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, //back
            -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, //left
            1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0,     //right
            0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0,     //top
            0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0  //botton
    };


    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "uniform mat4 uMVMatrix;" +
                    "attribute vec4 vPosition;" +
                    "attribute vec3 vNormal;" +
                    "varying vec3 aNormal;" +
                    "varying vec3 aPosition;" +
                    "void main() {" +
                    "aPosition = vec3(uMVMatrix * vPosition);" +
                    "aNormal = normalize(mat3(uMVMatrix)*vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "uniform vec3 lightPosition;" +
                    "varying vec3 aNormal;" +
                    "varying vec3 aPosition;" +
                    "void main() {" +
                    "vec3 lightDir = normalize(lightPosition - aPosition);" +
                    "float diff = max(dot(aNormal, lightDir),0.0);" +
                    "vec4 diffuse = diff * vColor;" +
                    "gl_FragColor = diffuse;" +
                    "}";

    public Cube() {
        // Inicializar buffer de vértices
        ByteBuffer bb = ByteBuffer.allocateDirect(cubeCoords.length * 4);
        bb.order(ByteOrder.nativeOrder());
        vertexBuffer = bb.asFloatBuffer();
        vertexBuffer.put(cubeCoords);
        vertexBuffer.position(0);

        // Inicializar buffer de normales
        ByteBuffer nb = ByteBuffer.allocateDirect(normals.length * 4);
        nb.order(ByteOrder.nativeOrder());
        normalBuffer = nb.asFloatBuffer();
        normalBuffer.put(normals);
        normalBuffer.position(0);

        // Inicializar buffer de orden de dibujo (ShortBuffer)
        ByteBuffer dlb = ByteBuffer.allocateDirect(drawOrder.length * 2);
        dlb.order(ByteOrder.nativeOrder());
        shortBuffer = dlb.asShortBuffer();
        shortBuffer.put(drawOrder);
        shortBuffer.position(0);

        // Carga de Shaders
        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    public void draw(float[] vpMatrix, float[] mvMatrix) {

        GLES20.glUseProgram(mProgram);

        int positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, 3,
                GLES20.GL_FLOAT, false, 3 * 4, vertexBuffer);
        //Normal
        int normalHandle = GLES20.glGetAttribLocation(mProgram, "vNormal");
        GLES20.glEnableVertexAttribArray(normalHandle);
        GLES20.glVertexAttribPointer(normalHandle, 3,
                GLES20.GL_FLOAT, false, 3 * 4, normalBuffer);

        int colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        //OTRA FORMA DE COLOCAR EL COLOR
        GLES20.glUniform4f(colorHandle, 1f, 0f, 0f, 1f);

        int matrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(matrixHandle, 1, false, vpMatrix, 0);
        //mv Matrix
        int mvMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVMatrix");
        GLES20.glUniformMatrix4fv(mvMatrixHandle, 1, false, mvMatrix, 0);


        //Posicion de la luz
        int lightHandle = GLES20.glGetUniformLocation(mProgram, "lightPosition");
        GLES20.glUniform3f(lightHandle, 1f, 1f, 1f);


        // Dibujar el cubo usando los índices
        GLES20.glDrawElements(
                GLES20.GL_TRIANGLES, drawOrder.length,
                GLES20.GL_UNSIGNED_SHORT, shortBuffer);

        GLES20.glDisableVertexAttribArray(positionHandle);
        GLES20.glDisableVertexAttribArray(normalHandle);
    }


}
