package com.objeto_iluminacionespecular;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Torus {
    private FloatBuffer vertexBuffer;
    private FloatBuffer normalBuffer;
    private ShortBuffer indexBuffer;

    private int mProgram;
    static final int COORDS_POR_VERTEX = 3;
    private final int vertexStride = COORDS_POR_VERTEX * 4;

    public Torus() {
        // Generar coordenadas y normales
        float[] torusCoords = createCoordsTorus(1f, 0.30f, 32, 16);
        float[] torusNormals = createNormalsTorus(32, 16);
        short[] torusIndex = createIndexTorus(32, 16);

        // Buffer de Vértices
        vertexBuffer = ByteBuffer.allocateDirect(torusCoords.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        vertexBuffer.put(torusCoords).position(0);

        // Buffer de Normales
        normalBuffer = ByteBuffer.allocateDirect(torusNormals.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        normalBuffer.put(torusNormals).position(0);

        // Buffer de Índices
        indexBuffer = ByteBuffer.allocateDirect(torusIndex.length * 2)
                .order(ByteOrder.nativeOrder()).asShortBuffer();
        indexBuffer.put(torusIndex).position(0);

        // Shaders
        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    public void draw(float[] mvpMatrix, float[] mvMatrix) {
        GLES20.glUseProgram(mProgram);

        // Handle de Posición
        int positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, COORDS_POR_VERTEX, GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);

        // Handle de Normales
        int normalHandle = GLES20.glGetAttribLocation(mProgram, "vNormal");
        GLES20.glEnableVertexAttribArray(normalHandle);
        GLES20.glVertexAttribPointer(normalHandle, COORDS_POR_VERTEX, GLES20.GL_FLOAT, false, vertexStride, normalBuffer);

        // Uniforms de Matrices
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVPMatrix"), 1, false, mvpMatrix, 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProgram, "uMVMatrix"), 1, false, mvMatrix, 0);

        // Uniforms de Iluminación
        GLES20.glUniform4f(GLES20.glGetUniformLocation(mProgram, "vColor"), 1f, 1f, 1f, 1.0f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "lightPosition"), 0f, 0f, 3f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProgram, "viewPosition"), 2.0f, 2.0f, 2.0f);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(mProgram, "shininees"), 4f);

        // Dibujar
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, 32 * 16 * 6, GLES20.GL_UNSIGNED_SHORT, indexBuffer);

        GLES20.glDisableVertexAttribArray(positionHandle);
        GLES20.glDisableVertexAttribArray(normalHandle);
    }


    private float[] createCoordsTorus(float R, float r, int mayor, int menor) {
        float[] v = new float[mayor * menor * 3];
        int p = 0;
        for (int i = 0; i < mayor; i++) {
            float t = (float) (2 * Math.PI * i / mayor);
            for (int j = 0; j < menor; j++) {
                float pAng = (float) (2 * Math.PI * j / menor);
                v[p++] = (float) ((R + r * Math.cos(pAng)) * Math.cos(t));
                v[p++] = (float) (r * Math.sin(pAng));
                v[p++] = (float) ((R + r * Math.cos(pAng)) * Math.sin(t));
            }
        }
        return v;
    }

    private float[] createNormalsTorus(int mayor, int menor) {
        float[] n = new float[mayor * menor * 3];
        int p = 0;
        for (int i = 0; i < mayor; i++) {
            float t = (float) (2 * Math.PI * i / mayor);
            for (int j = 0; j < menor; j++) {
                float pAng = (float) (2 * Math.PI * j / menor);
                // La normal de un toroide en un punto es simplemente la dirección del centro del tubo al punto
                n[p++] = (float) (Math.cos(pAng) * Math.cos(t));
                n[p++] = (float) (Math.sin(pAng));
                n[p++] = (float) (Math.cos(pAng) * Math.sin(t));
            }
        }
        return n;
    }

    private short[] createIndexTorus(int mayor, int menor) {
        short[] ind = new short[mayor * menor * 6];
        int k = 0;
        for (int i = 0; i < mayor; i++) {
            for (int j = 0; j < menor; j++) {
                int a = i * menor + j;
                int b = i * menor + (j + 1) % menor;
                int c = ((i + 1) % mayor) * menor + (j + 1) % menor;
                int d = ((i + 1) % mayor) * menor + j;
                ind[k++] = (short) a; ind[k++] = (short) b; ind[k++] = (short) c;
                ind[k++] = (short) a; ind[k++] = (short) c; ind[k++] = (short) d;
            }
        }
        return ind;
    }

    //Iluminación Difusa
//    private final String vertexShaderCode =
//            "uniform mat4 uMVPMatrix;" +
//            "uniform mat4 uMVMatrix;" +
//            "attribute vec4 vPosition;" +
//            "attribute vec3 vNormal;" +
//            "varying vec3 aNormal;" +
//            "varying vec3 aPosition;" +
//                    "void main() {" +
//                    "aPosition = vec3(uMVMatrix * vPosition);" +
//                    "aNormal = normalize(mat3(uMVMatrix)*vNormal);" +
//                    "  gl_Position = uMVPMatrix * vPosition;" +
//                    "}";
//
//    private final String fragmentShaderCode =
//            "precision mediump float;" +
//            "uniform vec4 vColor;" +
//            "uniform vec3 lightPosition;" +
//            "varying vec3 aNormal;" +
//            "varying vec3 aPosition;" +
//                    "void main() {" +
//                    "vec3 lightDir = normalize(lightPosition - aPosition);" +
//                    "float diff = max(dot(aNormal, lightDir),0.0);" +
//                    "vec4 diffuse = diff * vColor;" +
//                    "gl_FragColor = diffuse;" +
//                    "}";
//

    //Iluminación Especular
    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
             "uniform mat4 uMVMatrix;" +
             "attribute vec4 vPosition;" +
             "attribute vec3 vNormal;" +
             "varying vec3 aNormal;" +
             "varying vec3 aPosition;" +
                    "void main() {" +
                    "aPosition = vec3(uMVMatrix * vPosition);" +
                    "aNormal = normalize(mat3(uMVMatrix)*vNormal);" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
            "uniform vec4 vColor;" +
            "uniform vec3 lightPosition;" +
            "uniform vec3 viewPosition;" +
            "uniform float shininees;"+
            "varying vec3 aNormal;" +
            "varying vec3 aPosition;" +
                    "void main() {" +
                    "vec3 N = normalize(aNormal);" +
                    "vec3 L = normalize(lightPosition-aPosition);" +
                    "vec3 V = normalize(viewPosition-aPosition);" +
                    "vec3 R = reflect(-L,N);" +
                    "float spec = pow(max(dot(V,R), 0.0), shininees);" +
                    "vec4 specular = vColor*spec;" +
                    "  gl_FragColor = specular;" +
                    "}";
}
