package com.malla;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {

    // Si tienes una clase Ejes, úsala. Si no, comenta esta línea.
    // private Ejes ejes;
    private GridMesh mGridMesh;

    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    private final float[] mVPMatrix = new float[16];
    private final float[] mModelMatrix = new float[16];
    private float rotationAngle = 0.0f;

    // Parámetros de cámara: Ajustados para visualizar el cubo 2x2x2
    public float camaraX = 0.5f;
    public float camaraY = 0.5f;
    public float camaraZ = 0.5f;

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        // 1. Calcular Matriz de Vista (Cámara)
        Matrix.setLookAtM(
                mViewMatrix, 0,
                camaraX, camaraY, camaraZ,
                0f, 0f, 0f,
                0f, 1f, 0f
        );

        // 2. Calcular Matriz Proyección * Vista (VP)
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mViewMatrix, 0);

        // --- CÓDIGO DE ROTACIÓN 3D VOLUMÉTRICA ---
        /*rotationAngle += 0.5f;
        if (rotationAngle > 360) rotationAngle -= 360;*/

        // 3. Establecer Matriz de Modelo (Rotación Compuesta)
        Matrix.setIdentityM(mModelMatrix, 0);
        Matrix.rotateM(mModelMatrix, 0, rotationAngle, 0.0f, 1.0f, 0.0f); // Rotación en Y
        Matrix.rotateM(mModelMatrix, 0, rotationAngle * 0.7f, 1.0f, 0.0f, 0.0f); // Rotación en X

        // 4. Calcular la Matriz Final (MVP) para la Malla
        float[] finalMVPMatrix_Malla = new float[16];
        Matrix.multiplyMM(finalMVPMatrix_Malla, 0, mVPMatrix, 0, mModelMatrix, 0);

        // --- DIBUJO ---
        if (mGridMesh != null) {
            mGridMesh.draw(finalMVPMatrix_Malla);
        }
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Fondo negro para contraste
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        // Inicializar
        // ejes = new Ejes();
        mGridMesh = new GridMesh();
    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0,0,width,height);
        float ratio = (float) width / height;

        Matrix.frustumM(
                mProjectionMatrix, 0,
                -ratio, ratio,
                -1, 1,
                1.0f, 10f // Plano cercano en 1.0f
        );
    }

    // Método para cargar el shader (Tipo de shader, código del shader en GLSL)
    public static int loadShader(int type, String shaderCode){
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);

        // COMPROBACIÓN DE ERRORES DE COMPILACIÓN (VITAL)
        final int[] compileStatus = new int[1];
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0);

        if (compileStatus[0] == 0) {
            String log = GLES20.glGetShaderInfoLog(shader);
            GLES20.glDeleteShader(shader);
            System.err.println("Shader Compilation Error: " + log);
        }
        return shader;
    }
}