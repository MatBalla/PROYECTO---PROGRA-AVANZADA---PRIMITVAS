package com.malla;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class GridMesh {

    // --- Parámetros de la Malla Volumétrica ---
    private final int MESH_DIVISIONS = 8;
    private final float MESH_SIZE = 2.0f;
    private final int COORDS_PER_VERTEX = 3;

    private FloatBuffer vertexBuffer;
    private ShortBuffer drawListBuffer;
    private int vertexCount;
    private int indexCount;
    private int mProgram;

    private final float[] color = { 1.0f, 1.0f, 1.0f, 1.0f };

    // --- Vertex Shader ---
    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 vPosition;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "  gl_PointSize = 5.0;" +
                    "}";

    // --- Fragment Shader ---
    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "void main() {" +
                    "  gl_FragColor = vColor;" +
                    "}";

    // --- Constructor ---
    public GridMesh() {
        generateGeometry();

        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);

        // COMPROBACIÓN DE ERRORES DE LINKEO (VITAL)
        final int[] linkStatus = new int[1];
        GLES20.glGetProgramiv(mProgram, GLES20.GL_LINK_STATUS, linkStatus, 0);
        if (linkStatus[0] == 0) {
            String log = GLES20.glGetProgramInfoLog(mProgram);
            GLES20.glDeleteProgram(mProgram);
            System.err.println("Program Link Error: " + log);
        }
    }

    // --- Método de Generación con Triple FOR ---
    private void generateGeometry() {
        int numVertices = MESH_DIVISIONS + 1; // Puntos por eje (ej: 9)
        int verticesPerPlane = numVertices * numVertices; // Puntos por plano (ej: 81)
        int totalVertices = numVertices * verticesPerPlane; // Total (ej: 729)
        float[] vertices = new float[totalVertices * COORDS_PER_VERTEX];

        float step = MESH_SIZE / MESH_DIVISIONS;
        int vIndex = 0;

        // 1. GENERACIÓN DE VÉRTICES (Triple FOR)
        for (int k = 0; k < numVertices; k++) { // Z
            for (int j = 0; j < numVertices; j++) { // Y
                for (int i = 0; i < numVertices; i++) { // X

                    float x = -MESH_SIZE / 2.0f + i * step;
                    float y = -MESH_SIZE / 2.0f + j * step;
                    float z = -MESH_SIZE / 2.0f + k * step;

                    vertices[vIndex++] = x;
                    vertices[vIndex++] = y;
                    vertices[vIndex++] = z;
                }
            }
        }
        this.vertexCount = totalVertices;

        // Inicializar FloatBuffer
        ByteBuffer bb = ByteBuffer.allocateDirect(vertices.length * 4);
        bb.order(ByteOrder.nativeOrder());
        vertexBuffer = bb.asFloatBuffer();
        vertexBuffer.put(vertices);
        vertexBuffer.position(0);


        // 2. GENERACIÓN DE ÍNDICES (Líneas X, Y, Z)
        int numLinesPerAxis = MESH_DIVISIONS * numVertices * numVertices;
        int totalIndices = numLinesPerAxis * 3 * 2; // (Líneas por eje * 3 ejes * 2 índices por línea)
        short[] indices = new short[totalIndices];

        int iIndex = 0;

        // Conexiones X (Horizontales)
        for (int k = 0; k < numVertices; k++) {
            for (int j = 0; j < numVertices; j++) {
                for (int i = 0; i < MESH_DIVISIONS; i++) {
                    short v = (short) (k * verticesPerPlane + j * numVertices + i);
                    indices[iIndex++] = v;
                    indices[iIndex++] = (short) (v + 1);
                }
            }
        }

        // Conexiones Y (Verticales)
        for (int k = 0; k < numVertices; k++) {
            for (int j = 0; j < MESH_DIVISIONS; j++) {
                for (int i = 0; i < numVertices; i++) {
                    short v = (short) (k * verticesPerPlane + j * numVertices + i);
                    indices[iIndex++] = v;
                    indices[iIndex++] = (short) (v + numVertices);
                }
            }
        }

        // Conexiones Z (Profundidad)
        for (int k = 0; k < MESH_DIVISIONS; k++) {
            for (int j = 0; j < numVertices; j++) {
                for (int i = 0; i < numVertices; i++) {
                    short v = (short) (k * verticesPerPlane + j * numVertices + i);
                    indices[iIndex++] = v;
                    indices[iIndex++] = (short) (v + verticesPerPlane);
                }
            }
        }

        this.indexCount = iIndex;

        // Inicializar ShortBuffer (¡CORRECCIÓN DEL ERROR DE PUT!)
        ByteBuffer dlb = ByteBuffer.allocateDirect(indexCount * 2);
        dlb.order(ByteOrder.nativeOrder());

        drawListBuffer = dlb.asShortBuffer(); // Crear la vista ShortBuffer
        drawListBuffer.put(indices, 0, indexCount); // Usar el ShortBuffer para poner el array short[]
        drawListBuffer.position(0);
    }

    // --- Método de Dibujo Corregido ---
    public void draw(float[] mvpMatrix) {

        GLES20.glUseProgram(mProgram);

        // 1. Obtener y Habilitar Handle (posición)
        int positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);

        // Stride: 3 coordenadas * 4 bytes por float = 12
        final int vertexStride = COORDS_PER_VERTEX * 4;

        // 2. Pasar los datos de los vértices
        GLES20.glVertexAttribPointer(
                positionHandle,         // Handle del atributo vPosition
                COORDS_PER_VERTEX,      // 3: X, Y, Z
                GLES20.GL_FLOAT,
                false,
                vertexStride,
                vertexBuffer);

        // 3. Pasar la Matriz (MVP)
        int vPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(vPMatrixHandle, 1, false, mvpMatrix, 0);

        // 4. Pasar el color
        int colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        // 5. DIBUJAR LÍNEAS
        GLES20.glDrawElements(
                GLES20.GL_LINES,
                indexCount,
                GLES20.GL_UNSIGNED_SHORT,
                drawListBuffer);

        // 6. DIBUJAR PUNTOS
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, vertexCount);

        // 7. Deshabilitar: Usamos el Handle
        GLES20.glDisableVertexAttribArray(positionHandle);
    }
}